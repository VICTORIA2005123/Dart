package com.example.quotes

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
