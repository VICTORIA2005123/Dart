import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:flutter/foundation.dart';

void main() {
 runApp(const QuoteApp());
}

class Quote {
	final String text;
	final String author;

	Quote({required this.text, required this.author});

	factory Quote.fromJson(Map<String, dynamic> json) {
		// zenquotes.io uses 'q' for quote and 'a' for author
		return Quote(
			text: json['q'] ?? '',
			author: json['a'] ?? 'Unknown',
		);
	}
}

class QuoteApp extends StatelessWidget {
 const QuoteApp({Key? key}) : super(key: key);

 @override
 Widget build(BuildContext context) {
 return MaterialApp(
 title: 'Quote App',
 theme: ThemeData(
 primarySwatch: Colors.indigo,
 ),
 home: const QuoteScreen(),
 );
 }
}

class QuoteScreen extends StatefulWidget {
 const QuoteScreen({Key? key}) : super(key: key);

 @override
 State<QuoteScreen> createState() => _QuoteScreenState();
}

class _QuoteScreenState extends State<QuoteScreen> {
 late Future<Quote> _futureQuote;
 final List<Quote> _quoteHistory = [];

 @override
 void initState() {
 super.initState();
 _futureQuote = _fetchQuote();
 }

		Future<Quote> _fetchQuote() async {
			// Use CORS proxy for web, direct API for mobile/desktop
			final url = kIsWeb
					? 'https://api.allorigins.win/raw?url=https://zenquotes.io/api/random'
					: 'https://zenquotes.io/api/random/';
			final response = await http.get(Uri.parse(url));

			if (response.statusCode == 200) {
				// zenquotes.io returns a list, so decode accordingly
				final data = jsonDecode(response.body);
				final quote = Quote.fromJson(kIsWeb ? data[0] : data[0]);
				_quoteHistory.add(quote);
				return quote;
			} else {
				throw Exception('Failed to load quote');
			}
		}

 void _getNewQuote() {
 setState(() {
 _futureQuote = _fetchQuote();
 });
 }

 void _viewHistory() {
 Navigator.of(context).push(
 MaterialPageRoute(
 builder: (context) => QuoteHistoryScreen(quoteHistory: _quoteHistory),
 ),
 );
 }

 @override
 Widget build(BuildContext context) {
 return Scaffold(
 appBar: AppBar(
 title: const Text('Random Quotes'),
 actions: [
 IconButton(
 icon: const Icon(Icons.list),
 onPressed: _viewHistory,
 tooltip: 'View History',
 ),
 ],
 ),
 body: Center(
 child: Padding(
 padding: const EdgeInsets.all(20.0),
 child: FutureBuilder<Quote>(
 future: _futureQuote,
 builder: (context, snapshot) {
 if (snapshot.connectionState == ConnectionState.waiting) {
 return const CircularProgressIndicator();
 } else if (snapshot.hasError) {
 return Text('Error: ${snapshot.error}');
 } else if (snapshot.hasData) {
 return Column(
 mainAxisAlignment: MainAxisAlignment.center,
 children: [
 Text(
 '"${snapshot.data!.text}"',
 textAlign: TextAlign.center,
 style: const TextStyle(
 fontSize: 24,
 fontStyle: FontStyle.italic,
 ),
 ),
 const SizedBox(height: 20),
 Text(
 '- ${snapshot.data!.author}',
 style: const TextStyle(
 fontSize: 18,
 fontWeight: FontWeight.bold,
 ),
 ),
 ],
 );
 }
 return const Text('Press the refresh button to get a quote.');
 },
 ),
 ),
 ),
 floatingActionButton: FloatingActionButton(
 onPressed: _getNewQuote,
 tooltip: 'New Quote',
 child: const Icon(Icons.refresh),
 ),
 );
 }
}

class QuoteHistoryScreen extends StatelessWidget {
 final List<Quote> quoteHistory;

 const QuoteHistoryScreen({Key? key, required this.quoteHistory})
 : super(key: key);

 @override
 Widget build(BuildContext context) {
 return Scaffold(
 appBar: AppBar(
 title: const Text('Quote History'),
 ),
 body: ListView.builder(
 itemCount: quoteHistory.length,
 itemBuilder: (context, index) {
 final quote = quoteHistory[index];
 return Card(
 margin: const EdgeInsets.all(8.0),
 child: ListTile(
 title: Text(quote.text),
 subtitle: Text('- ${quote.author}'),
 ),
 );
 },
 ),
 );
 }
}