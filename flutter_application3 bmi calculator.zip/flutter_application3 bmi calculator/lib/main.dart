
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'dart:math';

void main() => runApp(const BMICalculator());

class BMICalculator extends StatelessWidget {
  const BMICalculator({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BMI Calculator',
      theme: ThemeData.dark().copyWith(
        primaryColor: const Color(0xFF0A0E21),
        scaffoldBackgroundColor: const Color(0xFF0A0E21),
      ),
      home: const InputPage(),
    );
  }
}

enum Gender { male, female }

class InputPage extends StatefulWidget {
  const InputPage({super.key});

  @override
  State<InputPage> createState() => _InputPageState();
}

class _InputPageState extends State<InputPage> {
  @override
  void dispose() {
    _heightController.dispose();
    _weightController.dispose();
    super.dispose();
  }
  Gender? selectedGender;
  int height = 178;
  int weight = 74;
  final TextEditingController _heightController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();
  String _bmiResult = '';

  void _calculateBmi() {
    setState(() {
      int? h = int.tryParse(_heightController.text);
      int? w = int.tryParse(_weightController.text);
      if (h != null && w != null && h > 0 && w > 0) {
        height = h;
        weight = w;
        double bmi = weight / pow(height / 100, 2);
        _bmiResult = bmi.toStringAsFixed(1);
      } else {
        _bmiResult = '--';
      }
    });
  }

  @override
  void initState() {
    super.initState();
    _heightController.text = height.toString();
    _weightController.text = weight.toString();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('BMI Calculator'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {},
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _genderCard(
                    icon: FontAwesomeIcons.venus,
                    label: 'Female',
                    selected: selectedGender == Gender.female,
                    onTap: () => setState(() => selectedGender = Gender.female),
                    color: Colors.pink,
                  ),
                  const SizedBox(width: 16),
                  _genderCard(
                    icon: FontAwesomeIcons.mars,
                    label: 'Male',
                    selected: selectedGender == Gender.male,
                    onTap: () => setState(() => selectedGender = Gender.male),
                    color: Colors.blue,
                  ),
                ],
              ),
              const SizedBox(height: 32),
              _manualInputCard('Your height in Cm', _heightController, Colors.white),
              const SizedBox(height: 16),
              _manualInputCard('Your Weight in Kg', _weightController, Colors.white),
              const SizedBox(height: 32),
              _infoCard('Your BMI', _bmiResult.isEmpty ? '--' : _bmiResult, null, Colors.white, big: true),
              const SizedBox(height: 32),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.indigo,
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                onPressed: _calculateBmi,
                child: const Text('Calculate', style: TextStyle(fontSize: 22)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _manualInputCard(String label, TextEditingController controller, Color color) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: TextStyle(color: color, fontSize: 18)),
          const SizedBox(height: 8),
          TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold),
            decoration: InputDecoration(
              filled: true,
              fillColor: Colors.black.withOpacity(0.1),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              hintText: label,
              hintStyle: const TextStyle(color: Colors.white54),
            ),
          ),
        ],
      ),
    );
  }

  Widget _genderCard({
    required IconData icon,
    required String label,
    required bool selected,
    required VoidCallback onTap,
    required Color color,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          height: 90,
          decoration: BoxDecoration(
            color: selected ? color.withOpacity(0.2) : Colors.transparent,
            border: Border.all(
              color: selected ? color : Colors.white,
              width: 2,
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: color, size: 40),
              const SizedBox(height: 8),
              Text(label, style: TextStyle(color: color, fontSize: 20)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _infoCard(String label, String value, VoidCallback? onTap, Color color, {bool big = false}) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Text(label, style: TextStyle(color: color, fontSize: 18)),
          const SizedBox(height: 8),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: big ? 40 : 28,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}