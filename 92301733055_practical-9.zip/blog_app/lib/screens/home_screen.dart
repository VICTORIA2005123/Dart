import 'package:flutter/material.dart';
import '../services/crud_service.dart';
import '../models/blog_post.dart';
import 'add_blog_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final CrudService _crudService = CrudService();

    return Scaffold(
      appBar: AppBar(title: const Text("My Awesome Blog")),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(context, 
            MaterialPageRoute(builder: (context) => const AddBlogScreen()));
        },
        child: const Icon(Icons.add),
      ),
      body: StreamBuilder<List<BlogPost>>(
        stream: _crudService.getBlogPosts(),
        builder: (context, snapshot) {
          if (snapshot.hasError) return const Center(child: Text("Error loading blogs"));
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final blogs = snapshot.data!;

          return ListView.builder(
            itemCount: blogs.length,
            itemBuilder: (context, index) {
              final blog = blogs[index];
              return Card(
                margin: const EdgeInsets.all(10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (blog.imageUrl.isNotEmpty)
                      Image.network(
                        blog.imageUrl,
                        height: 200,
                        width: MediaQuery.of(context).size.width,
                        fit: BoxFit.cover,
                      ),
                    Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(blog.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 5),
                          Text(blog.author, style: const TextStyle(color: Colors.grey)),
                          const SizedBox(height: 10),
                          Text(blog.content, maxLines: 3, overflow: TextOverflow.ellipsis),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}