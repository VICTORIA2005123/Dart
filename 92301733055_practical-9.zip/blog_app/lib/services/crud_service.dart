import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import '../models/blog_post.dart';

class CrudService {
  // Lazy reference to Firestore Collection to avoid early initialization
  CollectionReference get _blogCollection =>
      FirebaseFirestore.instance.collection('blogs');

  // 1. Upload Image to Firebase Storage
  Future<String?> uploadImage(File imageFile) async {
    try {
      String fileName = DateTime.now().millisecondsSinceEpoch.toString();
      Reference ref = FirebaseStorage.instance.ref().child(
        'blog_images/$fileName',
      );
      UploadTask uploadTask = ref.putFile(imageFile);
      TaskSnapshot snapshot = await uploadTask;
      return await snapshot.ref.getDownloadURL();
    } catch (e) {
      print("Error uploading image: $e");
      return null;
    }
  }

  // 2. Add Blog Post
  Future<void> addBlogPost(BlogPost blog) async {
    await _blogCollection.add(blog.toMap());
  }

  // 3. Get Blog Posts (Stream for real-time updates)
  Stream<List<BlogPost>> getBlogPosts() {
    return _blogCollection
        .orderBy('publishedDate', descending: true)
        .snapshots()
        .map((snapshot) {
          return snapshot.docs.map((doc) {
            return BlogPost.fromMap(doc.data() as Map<String, dynamic>, doc.id);
          }).toList();
        });
  }
}
