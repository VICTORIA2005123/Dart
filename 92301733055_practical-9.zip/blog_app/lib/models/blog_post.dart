class BlogPost {
  String id;
  String title;
  String content;
  String imageUrl;
  String author;
  DateTime publishedDate;

  BlogPost({
    required this.id,
    required this.title,
    required this.content,
    required this.imageUrl,
    required this.author,
    required this.publishedDate,
  });

  // Convert to Map for saving to Firebase
  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'content': content,
      'imageUrl': imageUrl,
      'author': author,
      'publishedDate': publishedDate.toIso8601String(),
    };
  }

  // Create Object from Firebase Data
  factory BlogPost.fromMap(Map<String, dynamic> map, String id) {
    return BlogPost(
      id: id,
      title: map['title'] ?? '',
      content: map['content'] ?? '',
      imageUrl: map['imageUrl'] ?? '',
      author: map['author'] ?? 'Anonymous',
      publishedDate: DateTime.parse(map['publishedDate']),
    );
  }
}