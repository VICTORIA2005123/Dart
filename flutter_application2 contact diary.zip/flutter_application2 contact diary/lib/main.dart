import 'package:flutter/material.dart';

// The main entry point for the application.
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Contact Diary',
      theme: ThemeData(
        primarySwatch: Colors.teal,
        // Adding a bit of visual flair to the cards and FAB.
        cardTheme: const CardThemeData(
          elevation: 4,
          margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(12)),
          ),
        ),
      ),
      home: const ContactListScreen(),
    );
  }
}

// Data Model: A simple class to represent a single contact.
// This helps in organizing the contact's information.
class Contact {
  String name;
  String mobile;
  String email;

  Contact({required this.name, required this.mobile, required this.email});
}

// The main screen which will display the list of contacts.
// It's a StatefulWidget because the list of contacts can change.
class ContactListScreen extends StatefulWidget {
  const ContactListScreen({super.key});

  @override
  State<ContactListScreen> createState() => _ContactListScreenState();
}

class _ContactListScreenState extends State<ContactListScreen> {
  // This is the state of our widget: a list of Contact objects.
  // We initialize it with some dummy data for demonstration.
  final List<Contact> _contacts = [
    Contact(name: 'Taye', mobile: '+91-802-555-181', email: 'Taye@email.com'),
    Contact(name: 'Pruce', mobile: '+91-973-735-456', email: 'Pruce@email.com'),
  ];

  // This method is called to add a new contact to our list.
  // It uses setState to notify Flutter that the UI needs to be rebuilt.
  void _addContact(Contact newContact) {
    setState(() {
      _contacts.add(newContact);
    });
  }

  // This function shows the dialog for adding a new contact.
  Future<void> _showAddContactDialog() async {
    // Controllers to manage the text input fields in the dialog.
    final TextEditingController nameController = TextEditingController();
    final TextEditingController mobileController = TextEditingController();
    final TextEditingController emailController = TextEditingController();
    final GlobalKey<FormState> formKey = GlobalKey<FormState>();

    // showDialog returns a Future that completes when the dialog is dismissed.
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // User must tap a button to dismiss.
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Add New Contact'),
          content: SingleChildScrollView(
            child: Form(
              key: formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  TextFormField(
                    controller: nameController,
                    decoration: const InputDecoration(labelText: 'Contact Name'),
                    validator: (value) => value == null || value.isEmpty ? 'Please enter a name' : null,
                  ),
                  TextFormField(
                    controller: mobileController,
                    decoration: const InputDecoration(labelText: 'Mobile Number'),
                    keyboardType: TextInputType.phone,
                     validator: (value) => value == null || value.isEmpty ? 'Please enter a mobile number' : null,
                  ),
                  TextFormField(
                    controller: emailController,
                    decoration: const InputDecoration(labelText: 'Email Address'),
                    keyboardType: TextInputType.emailAddress,
                     validator: (value) => value == null || value.isEmpty ? 'Please enter an email' : null,
                  ),
                ],
              ),
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop(); // Dismiss the dialog.
              },
            ),
            ElevatedButton(
              child: const Text('Save'),
              onPressed: () {
                // Validate the form before proceeding.
                if (formKey.currentState!.validate()) {
                   // Create a new Contact object from the input.
                  final newContact = Contact(
                    name: nameController.text,
                    mobile: mobileController.text,
                    email: emailController.text,
                  );
                  // Add the new contact to the list.
                  _addContact(newContact);
                  Navigator.of(context).pop(); // Dismiss the dialog.
                }
              },
            ),
          ],
        );
      },
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Contact Diary'),
      ),
      // The body uses a ListView.builder for efficient list rendering.
      body: ListView.builder(
        itemCount: _contacts.length,
        itemBuilder: (context, index) {
          final contact = _contacts[index];
          // Each contact is displayed in a styled Card widget.
          return Card(
            child: ListTile(
              leading: const Icon(Icons.person, color: Colors.teal, size: 40),
              title: Text(
                contact.name,
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 4),
                  Text(contact.mobile),
                  const SizedBox(height: 2),
                  Text(contact.email),
                ],
              ),
              isThreeLine: true, // Allows more space for the subtitle.
            ),
          );
        },
      ),
      // A FloatingActionButton to trigger the add contact dialog.
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddContactDialog,
        tooltip: 'Add Contact',
        child: const Icon(Icons.add),
      ),
    );
  }
}