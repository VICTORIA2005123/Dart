import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'GST Calculator',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const GstCalculatorScreen(),
    );
  }
}

class GstCalculatorScreen extends StatefulWidget {
  const GstCalculatorScreen({super.key});

  @override
  State<GstCalculatorScreen> createState() => _GstCalculatorScreenState();
}

class _GstCalculatorScreenState extends State<GstCalculatorScreen> {
  // Controllers to manage the input fields
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _gstController = TextEditingController();

  // Variables to hold the calculated values
  String _igst = '0.0';
  String _cgst = '0.0';
  String _sgst = '0.0';
  String _totalAmount = '0.0';
  String _actualAmount = '0.0';

  // Boolean to toggle between the two calculation cases
  bool _isReverseCalculation = false;

  // This function will perform the GST calculation
  void _calculateGst() {
    // Get the input values from the text fields
    final double amount = double.tryParse(_amountController.text) ?? 0.0;
    final double gstPercentage = double.tryParse(_gstController.text) ?? 0.0;

    // Ensure the inputs are not negative
    if (amount < 0 || gstPercentage < 0) {
      return;
    }

    // Use a setState to update the UI with the new values
    setState(() {
      if (!_isReverseCalculation) {
        // Case 1: Forward GST Calculation
        final double gstAmount = (amount * gstPercentage) / 100;
        _totalAmount = (amount + gstAmount).toStringAsFixed(2);
        _igst = gstAmount.toStringAsFixed(2);
        _cgst = (gstAmount / 2).toStringAsFixed(2);
        _sgst = (gstAmount / 2).toStringAsFixed(2);
        _actualAmount = amount.toStringAsFixed(2);
      } else {
        // Case 2: Reverse GST Calculation
        _actualAmount = (amount / (1 + (gstPercentage / 100))).toStringAsFixed(2);
        final double gstAmount = amount - double.parse(_actualAmount);
        _igst = gstAmount.toStringAsFixed(2);
        _cgst = (gstAmount / 2).toStringAsFixed(2);
        _sgst = (gstAmount / 2).toStringAsFixed(2);
        _totalAmount = amount.toStringAsFixed(2);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('GST Calculator'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              // Switch to toggle between calculation modes
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('Calculate from Actual Amount'),
                  Switch(
                    value: _isReverseCalculation,
                    onChanged: (value) {
                      setState(() {
                        _isReverseCalculation = value;
                        // Clear the fields when switching modes
                        _amountController.clear();
                        _gstController.clear();
                        _igst = '0.0';
                        _cgst = '0.0';
                        _sgst = '0.0';
                        _totalAmount = '0.0';
                        _actualAmount = '0.0';
                      });
                    },
                  ),
                  const Text('Calculate from Total Amount'),
                ],
              ),
              const SizedBox(height: 20),

              // Input field for the amount
              TextField(
                controller: _amountController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: _isReverseCalculation ? 'Total Amount' : 'Actual Amount',
                  border: const OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),

              // Input field for the GST percentage
              TextField(
                controller: _gstController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'GST %',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 30),

              // Button to trigger the calculation
              ElevatedButton(
                onPressed: _calculateGst,
                child: const Text('Calculate'),
              ),
              const SizedBox(height: 30),

              // Displaying the results
              const Text(
                'Results:',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              _buildResultRow('Actual Amount:', '₹ $_actualAmount'),
              _buildResultRow('IGST:', '₹ $_igst'),
              _buildResultRow('CGST:', '₹ $_cgst'),
              _buildResultRow('SGST:', '₹ $_sgst'),
              _buildResultRow('Total Amount:', '₹ $_totalAmount', isTotal: true),
            ],
          ),
        ),
      ),
    );
  }

  // A helper widget to build each result row for better code organization
  Widget _buildResultRow(String title, String value, {bool isTotal = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 16,
              fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}