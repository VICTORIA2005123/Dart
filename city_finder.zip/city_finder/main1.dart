import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Indian Pincode to City Finder',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const PincodeFinderPage(),
    );
  }
}

class PincodeFinderPage extends StatefulWidget {
  const PincodeFinderPage({super.key});

  @override
  State<PincodeFinderPage> createState() => _PincodeFinderPageState();
}

class _PincodeFinderPageState extends State<PincodeFinderPage> {
  final TextEditingController _pincodeController = TextEditingController();
  Map<String, dynamic>? _result;
  bool _isLoading = false;
  String? _errorMessage;

  @override
  void dispose() {
    _pincodeController.dispose();
    super.dispose();
  }

  Future<void> _searchPincode() async {
    final pincode = _pincodeController.text.trim();

    // Validate pincode
    if (pincode.isEmpty) {
      setState(() {
        _errorMessage = 'Please enter a pincode';
        _result = null;
      });
      return;
    }

    if (pincode.length != 6 || !RegExp(r'^[0-9]{6}$').hasMatch(pincode)) {
      setState(() {
        _errorMessage = 'Please enter a valid 6-digit pincode';
        _result = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _result = null;
    });

    try {
      final response = await http
          .get(Uri.parse('https://api.postalpincode.in/pincode/$pincode'))
          .timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data is List && data.isNotEmpty) {
          final firstItem = data[0];

          if (firstItem['Status'] == 'Success') {
            final postOffices = firstItem['PostOffice'] as List?;
            if (postOffices != null && postOffices.isNotEmpty) {
              final firstOffice = postOffices[0];
              setState(() {
                _result = {
                  'pincode': pincode,
                  'city': firstOffice['District'] ?? 'N/A',
                  'district': firstOffice['District'] ?? 'N/A',
                  'state': firstOffice['State'] ?? 'N/A',
                };
              });
            } else {
              setState(() {
                _errorMessage = 'No data found for this pincode';
              });
            }
          } else {
            setState(() {
              _errorMessage = 'Pincode not found';
            });
          }
        }
      } else {
        setState(() {
          _errorMessage = 'Error: ${response.statusCode}';
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Error: Unable to fetch data. Please try again.';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Indian Pincode to City Finder'),
        centerTitle: true,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              // Title
              const SizedBox(height: 20),
              Text(
                'Find City & State by Pincode',
                style: Theme.of(context).textTheme.headlineSmall,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 30),

              // Input TextField
              TextField(
                controller: _pincodeController,
                keyboardType: TextInputType.number,
                maxLength: 6,
                decoration: InputDecoration(
                  labelText: 'Enter Pincode',
                  hintText: 'e.g., 400001',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  prefixIcon: const Icon(Icons.location_on),
                  counterText: '',
                ),
                onSubmitted: (_) => _searchPincode(),
              ),
              const SizedBox(height: 20),

              // Search Button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _isLoading ? null : _searchPincode,
                  icon: _isLoading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                          ),
                        )
                      : const Icon(Icons.search),
                  label: Text(_isLoading ? 'Searching...' : 'Search'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 40),

              // Error Message
              if (_errorMessage != null)
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.red[50],
                    border: Border.all(color: Colors.red),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.error_outline, color: Colors.red[700]),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          _errorMessage!,
                          style: TextStyle(color: Colors.red[700]),
                        ),
                      ),
                    ],
                  ),
                ),

              // Results
              if (_result != null)
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.green[50],
                    border: Border.all(color: Colors.green),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.check_circle, color: Colors.green[700]),
                          const SizedBox(width: 8),
                          Text(
                            'Results Found',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.green[700],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      _buildResultRow('Pincode:', _result!['pincode']),
                      const SizedBox(height: 12),
                      _buildResultRow('City:', _result!['city']),
                      const SizedBox(height: 12),
                      _buildResultRow('District:', _result!['district']),
                      const SizedBox(height: 12),
                      _buildResultRow('State:', _result!['state']),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResultRow(String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 80,
          child: Text(
            label,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 14,
            ),
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              fontSize: 14,
            ),
          ),
        ),
      ],
    );
  }
}
