import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const TemperatureConverterApp());
}

class TemperatureConverterApp extends StatelessWidget {
  const TemperatureConverterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TempConvert Pro',
      theme: ThemeData(
        primarySwatch: Colors.deepOrange,
        useMaterial3: true,
      ),
      home: const ConverterScreen(),
    );
  }
}

class ConverterScreen extends StatefulWidget {
  const ConverterScreen({super.key});

  @override
  State<ConverterScreen> createState() => _ConverterScreenState();
}

class _ConverterScreenState extends State<ConverterScreen> {
  // 1. Variables to hold input and results
  final TextEditingController _controller = TextEditingController();
  String _selectedUnit = 'Celsius';
  String _result1 = "--";
  String _result2 = "--";
  String _label1 = "Fahrenheit";
  String _label2 = "Kelvin";
  String? _errorText;

  // 2. Arithmetic Logic and Conversion
  void _calculateTemperatures(String value) {
    if (value.isEmpty) {
      setState(() {
        _result1 = "--";
        _result2 = "--";
        _errorText = null;
      });
      return;
    }

    // Error Handling: Try parsing the input to a double
    double? inputTemp = double.tryParse(value);

    if (inputTemp == null) {
      setState(() {
        _errorText = "Please enter a valid number";
        _result1 = "Error";
        _result2 = "Error";
      });
      return;
    }

    setState(() {
      _errorText = null; // Clear error if input is valid
      
      // Operators and Basic Arithmetic Operations
      if (_selectedUnit == 'Celsius') {
        _label1 = "Fahrenheit";
        _label2 = "Kelvin";
        _result1 = ((inputTemp * 9 / 5) + 32).toStringAsFixed(2); // (C * 9/5) + 32
        _result2 = (inputTemp + 273.15).toStringAsFixed(2);       // C + 273.15
      } else if (_selectedUnit == 'Fahrenheit') {
        _label1 = "Celsius";
        _label2 = "Kelvin";
        _result1 = ((inputTemp - 32) * 5 / 9).toStringAsFixed(2); // (F - 32) * 5/9
        _result2 = (((inputTemp - 32) * 5 / 9) + 273.15).toStringAsFixed(2);
      } else if (_selectedUnit == 'Kelvin') {
        _label1 = "Celsius";
        _label2 = "Fahrenheit";
        _result1 = (inputTemp - 273.15).toStringAsFixed(2);       // K - 273.15
        _result2 = (((inputTemp - 273.15) * 9 / 5) + 32).toStringAsFixed(2);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Temperature Converter"),
        centerTitle: true,
        backgroundColor: Colors.deepOrangeAccent,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            // Input Section
            Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    DropdownButton<String>(
                      value: _selectedUnit,
                      isExpanded: true,
                      items: ['Celsius', 'Fahrenheit', 'Kelvin']
                          .map((unit) => DropdownMenuItem(value: unit, child: Text("Input Unit: $unit")))
                          .toList(),
                      onChanged: (value) {
                        setState(() {
                          _selectedUnit = value!;
                          _calculateTemperatures(_controller.text);
                        });
                      },
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: _controller,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      inputFormatters: [
                        // Validation: Only allow digits, one decimal point, and an optional leading minus sign
                        FilteringTextInputFormatter.allow(RegExp(r'^-?\d*\.?\d*')),
                      ],
                      decoration: InputDecoration(
                        labelText: 'Enter Temperature',
                        errorText: _errorText,
                        border: const OutlineInputBorder(),
                        suffixText: _selectedUnit[0],
                      ),
                      onChanged: _calculateTemperatures, // Dynamic Update
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 30),
            
            // Output Section
            const Text("Conversions", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const Divider(),
            
            Expanded(
              child: ListView(
                children: [
                  _resultCard(_label1, _result1, Colors.blue),
                  _resultCard(_label2, _result2, Colors.green),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Helper Widget for results
  Widget _resultCard(String label, String value, Color color) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: ListTile(
        leading: CircleAvatar(backgroundColor: color, child: Text(label[0], style: const TextStyle(color: Colors.white))),
        title: Text(label),
        trailing: Text(
          value,
          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}