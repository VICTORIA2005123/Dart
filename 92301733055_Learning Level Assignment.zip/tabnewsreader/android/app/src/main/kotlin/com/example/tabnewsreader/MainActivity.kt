package com.example.tabnewsreader

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
