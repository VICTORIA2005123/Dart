import 'package:flutter/material.dart';

void main() {
  runApp(const NewsReaderApp());
}

class NewsReaderApp extends StatelessWidget {
  const NewsReaderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'NewsFlash',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        useMaterial3: true,
      ),
      home: const NewsHomeScreen(),
    );
  }
}

class NewsHomeScreen extends StatelessWidget {
  const NewsHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Dummy Data for the articles
    final Map<String, List<Article>> newsData = {
      'Technology': [
        Article("AI Revolution", "Generative AI is transforming how we write code and create art."),
        Article("New Smartphone Launch", "The latest flagship features a 200MP camera and 3-day battery."),
        Article("Quantum Computing", "Scientists achieve a new milestone in error correction."),
      ],
      'Sports': [
        Article("Championship Finals", "The underdog team wins the trophy in a historic comeback."),
        Article("Transfer Market", "Top striker signs a record-breaking deal with a European giant."),
        Article("Olympic Prep", "Athletes gather for the qualifying rounds this weekend."),
      ],
      'Business': [
        Article("Stock Market Update", "Tech stocks rally as inflation concerns begin to ease."),
        Article("Startup Funding", "A local fintech startup raises \$50M in Series B funding."),
        Article("Global Trade", "New trade agreements signed to boost cross-border commerce."),
      ],
      'Entertainment': [
        Article("Movie Premiere", "The highly anticipated sci-fi epic breaks box office records."),
        Article("Music Awards", "The winners of this year's global music awards have been announced."),
        Article("Streaming Trends", "New survey shows a shift back to episodic television releases."),
      ],
    };

    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('NewsFlash'),
          centerTitle: true,
          bottom: const TabBar(
            isScrollable: true,
            tabs: [
              Tab(icon: Icon(Icons.biotech), text: "Technology"),
              Tab(icon: Icon(Icons.sports_soccer), text: "Sports"),
              Tab(icon: Icon(Icons.business), text: "Business"),
              Tab(icon: Icon(Icons.movie), text: "Entertainment"),
            ],
          ),
        ),
        // Drawer Implementation
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              const DrawerHeader(
                decoration: BoxDecoration(color: Colors.indigo),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircleAvatar(
                      backgroundColor: Colors.white,
                      radius: 30,
                      child: Icon(Icons.person, color: Colors.indigo, size: 40),
                    ),
                    SizedBox(height: 10),
                    Text(
                      'Welcome, Reader',
                      style: TextStyle(color: Colors.white, fontSize: 18),
                    ),
                  ],
                ),
              ),
              ListTile(
                leading: const Icon(Icons.settings),
                title: const Text('Settings'),
                onTap: () => Navigator.pop(context),
              ),
              ListTile(
                leading: const Icon(Icons.info),
                title: const Text('About'),
                onTap: () => Navigator.pop(context),
              ),
              ListTile(
                leading: const Icon(Icons.share),
                title: const Text('Share App'),
                onTap: () => Navigator.pop(context),
              ),
            ],
          ),
        ),
        // Body with TabBarView
        body: TabBarView(
          children: [
            NewsListView(articles: newsData['Technology']!),
            NewsListView(articles: newsData['Sports']!),
            NewsListView(articles: newsData['Business']!),
            NewsListView(articles: newsData['Entertainment']!),
          ],
        ),
      ),
    );
  }
}

// Reusable Widget for the List of News
class NewsListView extends StatelessWidget {
  final List<Article> articles;

  const NewsListView({super.key, required this.articles});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(8.0),
      itemCount: articles.length,
      itemBuilder: (context, index) {
        return Card(
          elevation: 2,
          margin: const EdgeInsets.symmetric(vertical: 8),
          child: ListTile(
            contentPadding: const EdgeInsets.all(12),
            title: Text(
              articles[index].title,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            subtitle: Padding(
              padding: const EdgeInsets.only(top: 8.0),
              child: Text(
                articles[index].description,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () {
              // Action when tapping an article
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Opening: ${articles[index].title}')),
              );
            },
          ),
        );
      },
    );
  }
}

// Simple Article Model
class Article {
  final String title;
  final String description;

  Article(this.title, this.description);
}