package com.example.multiprofilepage_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
