import 'package:flutter/material.dart';

void main() {
  runApp(const MultiPageProfileApp());
}

// 1. Data Model to pass between screens
class UserProfile {
  final String name;
  final String email;
  final String bio;

  UserProfile(this.name, this.email, this.bio);
}

class MultiPageProfileApp extends StatelessWidget {
  const MultiPageProfileApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Multi-Page Profile App',
      theme: ThemeData(primarySwatch: Colors.indigo, useMaterial3: true),
      // Defining the Route Table
      initialRoute: '/',
      routes: {
        '/': (context) => const HomeScreen(),
        '/profile': (context) => const ProfileScreen(),
        '/settings': (context) => const SettingsScreen(),
      },
    );
  }
}

// --- SCREEN 1: HOME ---
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Home")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.home, size: 80, color: Colors.indigo),
            const SizedBox(height: 20),
            const Text(
              "Welcome to the App!",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 40),
            ElevatedButton.icon(
              icon: const Icon(Icons.person),
              label: const Text("View Profile"),
              onPressed: () {
                // Passing data via named route arguments
                Navigator.pushNamed(
                  context,
                  '/profile',
                  arguments: UserProfile(
                    "John Doe",
                    "john.doe@example.com",
                    "Flutter Developer & UI Enthusiast",
                  ),
                );
              },
            ),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              icon: const Icon(Icons.settings),
              label: const Text("App Settings"),
              onPressed: () {
                Navigator.pushNamed(context, '/settings');
              },
            ),
          ],
        ),
      ),
    );
  }
}

// --- SCREEN 2: PROFILE (Receives Data) ---
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Extracting arguments passed from the Home screen
    final args = ModalRoute.of(context)!.settings.arguments as UserProfile;

    return Scaffold(
      appBar: AppBar(
        title: const Text("User Profile"),
        backgroundColor: Colors.indigo.shade100,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            const CircleAvatar(
              radius: 50,
              child: Icon(Icons.person, size: 50),
            ),
            const SizedBox(height: 20),
            Card(
              child: ListTile(
                leading: const Icon(Icons.badge),
                title: const Text("Name"),
                subtitle: Text(args.name),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.email),
                title: const Text("Email"),
                subtitle: Text(args.email),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.info),
                title: const Text("Bio"),
                subtitle: Text(args.bio),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// --- SCREEN 3: SETTINGS (Stateful for dummy switches) ---
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notifications = true;
  bool _darkMode = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Settings")),
      body: ListView(
        children: [
          SwitchListTile(
            title: const Text("Enable Notifications"),
            subtitle: const Text("Receive daily updates"),
            value: _notifications,
            onChanged: (val) => setState(() => _notifications = val),
          ),
          SwitchListTile(
            title: const Text("Dark Mode"),
            subtitle: const Text("Switch to a darker theme"),
            value: _darkMode,
            onChanged: (val) => setState(() => _darkMode = val),
          ),
          const Divider(),
          ListTile(
            title: const Text("App Version"),
            trailing: const Text("1.0.0"),
            onTap: () {},
          ),
        ],
      ),
    );
  }
}
