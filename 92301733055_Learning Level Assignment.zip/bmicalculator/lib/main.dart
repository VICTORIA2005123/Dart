import 'package:flutter/material.dart';

void main() {
  runApp(const BMICalculatorApp());
}

class BMICalculatorApp extends StatelessWidget {
  const BMICalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BMI Calculator',
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: const BMIScreen(),
    );
  }
}

class BMIScreen extends StatefulWidget {
  const BMIScreen({super.key});

  @override
  State<BMIScreen> createState() => _BMIScreenState();
}

class _BMIScreenState extends State<BMIScreen> {
  // Controllers to retrieve text from fields
  final TextEditingController _heightController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();

  double? _bmiResult;
  String _category = "";
  Color _categoryColor = Colors.black;

  // Logic Function: Calculates BMI and determines category
  void _calculateBMI() {
    double? height = double.tryParse(_heightController.text);
    double? weight = double.tryParse(_weightController.text);

    if (height != null && weight != null && height > 0) {
      // BMI Formula: weight (kg) / [height (m)]^2
      double heightInMeters = height / 100;
      double bmi = weight / (heightInMeters * heightInMeters);

      setState(() {
        _bmiResult = bmi;

        // Conditional Statements for Category
        if (_bmiResult! < 18.5) {
          _category = "Underweight";
          _categoryColor = Colors.orange;
        } else if (_bmiResult! >= 18.5 && _bmiResult! < 25) {
          _category = "Normal";
          _categoryColor = Colors.green;
        } else if (_bmiResult! >= 25 && _bmiResult! < 30) {
          _category = "Overweight";
          _categoryColor = Colors.deepOrange;
        } else {
          _category = "Obese";
          _categoryColor = Colors.red;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("BMI Calculator")),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            // Height Input
            TextField(
              controller: _heightController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Height (cm)",
                icon: Icon(Icons.height),
              ),
            ),
            const SizedBox(height: 20),
            
            // Weight Input
            TextField(
              controller: _weightController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: "Weight (kg)",
                icon: Icon(Icons.monitor_weight_outlined),
              ),
            ),
            const SizedBox(height: 30),

            // Calculate Button
            ElevatedButton(
              onPressed: _calculateBMI,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(horizontal: 50, vertical: 15),
              ),
              child: const Text("Calculate BMI", style: TextStyle(fontSize: 18)),
            ),
            const SizedBox(height: 40),

            // Display Results
            if (_bmiResult != null)
              Column(
                children: [
                  const Text(
                    "Your BMI is:",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w300),
                  ),
                  Text(
                    _bmiResult!.toStringAsFixed(1),
                    style: const TextStyle(
                      fontSize: 60,
                      fontWeight: FontWeight.bold,
                      color: Colors.indigo,
                    ),
                  ),
                  Text(
                    _category,
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.w600,
                      color: _categoryColor,
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}