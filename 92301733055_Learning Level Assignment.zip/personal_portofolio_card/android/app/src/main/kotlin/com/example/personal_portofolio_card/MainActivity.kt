package com.example.personal_portofolio_card

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
