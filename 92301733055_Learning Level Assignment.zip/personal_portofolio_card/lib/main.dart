import 'package:flutter/material.dart';

void main() {
  runApp(const PortfolioApp());
}

class PortfolioApp extends StatelessWidget {
  const PortfolioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Personal Portfolio Card',
      // CUSTOM THEME: Defining primary and accent colors
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.indigo,
          primary: Colors.indigo,
          secondary: Colors.amberAccent,
        ),
      ),
      home: const PortfolioCard(),
    );
  }
}

class PortfolioCard extends StatelessWidget {
  const PortfolioCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Using the primary color for the background
      backgroundColor: Theme.of(context).colorScheme.primary,
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // 1. PROFILE PHOTO
              const CircleAvatar(
                radius: 60.0,
                backgroundColor: Colors.white,
                // Using a placeholder image from Unsplash
                backgroundImage: NetworkImage('https://images.unsplash.com/photo-1511367461989-f85a21fda167?w=400'),
              ),
              
              // 2. NAME
              const Text(
                'Victoria Vedastus',
                style: TextStyle(
                  fontSize: 40.0,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5,
                ),
              ),

              // 3. BRIEF BIO
              Text(
                'FLUTTER DEVELOPER & UI DESIGNER',
                style: TextStyle(
                  fontSize: 14.0,
                  color: Colors.indigo.shade100,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2.5,
                ),
              ),

              // A horizontal line for visual separation
              SizedBox(
                height: 20.0,
                width: 150.0,
                child: Divider(
                  color: Colors.indigo.shade100,
                ),
              ),

              // 4. PHONE NUMBER CARD
              Card(
                margin: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
                child: ListTile(
                  leading: const Icon(
                    Icons.phone,
                    color: Colors.indigo,
                  ),
                  title: Text(
                    '+91 923 456 7890',
                    style: TextStyle(
                      color: Colors.indigo.shade900,
                      fontSize: 18.0,
                    ),
                  ),
                ),
              ),

              // 5. EMAIL CARD
              Card(
                margin: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 25.0),
                child: ListTile(
                  leading: const Icon(
                    Icons.email,
                    color: Colors.indigo,
                  ),
                  title: Text(
                    'victoria01005@gmail.com',
                    style: TextStyle(
                      color: Colors.indigo.shade900,
                      fontSize: 18.0,
                    ),
                  ),
                ),
              ),
              
              // BIO DESCRIPTION
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 40.0, vertical: 20.0),
                child: Text(
                  'I build beautiful, high-performance mobile applications using Flutter. Passionate about clean code and modern UX design.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white70,
                    fontStyle: FontStyle.italic,
                    fontSize: 16.0,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}