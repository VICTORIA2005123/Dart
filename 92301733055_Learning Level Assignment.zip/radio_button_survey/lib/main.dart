import 'package:flutter/material.dart';

void main() {
  runApp(const RadioSurveyApp());
}

// --- 1. THE MODEL CLASS ---
// This must have fields to store the text, options, and the user's choice.
class Question {
  final String questionText;
  final List<String> options;
  int? selectedOptionIndex; // Stores the index of the selected radio button

  Question({
    required this.questionText,
    required this.options,
    this.selectedOptionIndex,
  });
}

class RadioSurveyApp extends StatelessWidget {
  const RadioSurveyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Survey App',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const SurveyScreen(),
    );
  }
}

class SurveyScreen extends StatefulWidget {
  const SurveyScreen({super.key});

  @override
  State<SurveyScreen> createState() => _SurveyScreenState();
}

class _SurveyScreenState extends State<SurveyScreen> {
  // Initialize the list using the model class
  final List<Question> _questions = [
    Question(
      questionText: "How would you rate our app's performance?",
      options: ["Excellent", "Good", "Average", "Poor"],
    ),
    Question(
      questionText: "Which feature do you use most often?",
      options: ["Dashboard", "Settings", "Profile", "Notifications"],
    ),
    Question(
      questionText: "How likely are you to recommend us?",
      options: ["Very Likely", "Likely", "Unlikely", "Never"],
    ),
    Question(
      questionText: "Is the user interface easy to navigate?",
      options: ["Yes, very easy", "Somewhat easy", "A bit confusing", "Very difficult"],
    ),
    Question(
      questionText: "What is your preferred contact method?",
      options: ["Email", "Phone", "In-App Chat", "No Contact"],
    ),
  ];

  int _currentIndex = 0;

  void _nextQuestion() {
    if (_currentIndex < _questions.length - 1) {
      setState(() => _currentIndex++);
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => SummaryScreen(questions: _questions),
        ),
      );
    }
  }

  void _previousQuestion() {
    if (_currentIndex > 0) {
      setState(() => _currentIndex--);
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentQuestion = _questions[_currentIndex];

    return Scaffold(
      appBar: AppBar(
        title: Text("Survey: ${_currentIndex + 1} of ${_questions.length}"),
        centerTitle: true,
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            LinearProgressIndicator(
              value: (_currentIndex + 1) / _questions.length,
            ),
            const SizedBox(height: 30),
            Text(
              currentQuestion.questionText,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            // Proper Grouping: groupValue links the radio buttons together
            Expanded(
              child: ListView.builder(
                itemCount: currentQuestion.options.length,
                itemBuilder: (context, index) {
                  return RadioListTile<int>(
                    title: Text(currentQuestion.options[index]),
                    value: index,
                    groupValue: currentQuestion.selectedOptionIndex,
                    onChanged: (val) {
                      setState(() {
                        currentQuestion.selectedOptionIndex = val;
                      });
                    },
                  );
                },
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                if (_currentIndex > 0)
                  OutlinedButton(
                    onPressed: _previousQuestion,
                    child: const Text("Back"),
                  )
                else
                  const SizedBox.shrink(),
                ElevatedButton(
                  onPressed: currentQuestion.selectedOptionIndex != null
                      ? _nextQuestion
                      : null, // Button disabled until an option is picked
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.indigo,
                    foregroundColor: Colors.white,
                  ),
                  child: Text(_currentIndex == _questions.length - 1
                      ? "Finish"
                      : "Next"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// --- 3. THE SUMMARY SCREEN ---
class SummaryScreen extends StatelessWidget {
  final List<Question> questions;

  const SummaryScreen({super.key, required this.questions});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Survey Summary")),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: questions.length,
        itemBuilder: (context, index) {
          final q = questions[index];
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Q${index + 1}: ${q.questionText}",
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "Answer: ${q.selectedOptionIndex != null ? q.options[q.selectedOptionIndex!] : 'No Answer'}",
                    style: const TextStyle(color: Colors.indigo, fontSize: 16, fontWeight: FontWeight.w500),
                  ),
                ],
              ),
            ),
          );
        },
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ElevatedButton(
          onPressed: () {
            // Reset and go back to start
            for (var q in questions) {
              q.selectedOptionIndex = null;
            }
            Navigator.of(context).popUntil((route) => route.isFirst);
          },
          child: const Text("Restart Survey"),
        ),
      ),
    );
  }
}