package com.example.radio_button_survey

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
