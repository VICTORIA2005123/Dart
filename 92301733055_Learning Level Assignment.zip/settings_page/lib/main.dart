import 'package:flutter/material.dart';

void main() {
  runApp(const SettingsApp());
}

class SettingsApp extends StatefulWidget {
  const SettingsApp({super.key});

  @override
  State<SettingsApp> createState() => _SettingsAppState();
}

class _SettingsAppState extends State<SettingsApp> {
  // 1. State Variables
  bool _isDarkMode = false;
  bool _notificationsEnabled = true;
  double _fontSize = 16.0;
  double _volume = 0.7;
  
  final List<String> _categories = ['Technology', 'Design', 'Music', 'Fitness', 'Travel'];
  final List<String> _selectedInterests = ['Technology'];

  void _toggleInterest(String category) {
    setState(() {
      if (_selectedInterests.contains(category)) {
        _selectedInterests.remove(category);
      } else {
        _selectedInterests.add(category);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: _isDarkMode ? ThemeData.dark(useMaterial3: true) : ThemeData.light(useMaterial3: true),
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Settings & Preferences'),
          centerTitle: true,
          elevation: 2,
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // PREVIEW SECTION
                _buildPreviewSection(),
                
                const SizedBox(height: 24),
                const Divider(),
                const SizedBox(height: 16),

                // SETTINGS CONTROLS
                _buildSectionHeader('Appearance & Alerts'),
                SwitchListTile(
                  title: const Text('Dark Mode'),
                  secondary: Icon(_isDarkMode ? Icons.dark_mode : Icons.light_mode),
                  value: _isDarkMode,
                  onChanged: (val) => setState(() => _isDarkMode = val),
                ),
                SwitchListTile(
                  title: const Text('Push Notifications'),
                  secondary: const Icon(Icons.notifications_active),
                  value: _notificationsEnabled,
                  onChanged: (val) => setState(() => _notificationsEnabled = val),
                ),

                const SizedBox(height: 20),
                _buildSectionHeader('System Volume'),
                Row(
                  children: [
                    const Icon(Icons.volume_down),
                    Expanded(
                      child: Slider(
                        value: _volume,
                        onChanged: (val) => setState(() => _volume = val),
                      ),
                    ),
                    const Icon(Icons.volume_up),
                  ],
                ),

                const SizedBox(height: 20),
                _buildSectionHeader('Reading Font Size (${_fontSize.toInt()}px)'),
                Slider(
                  value: _fontSize,
                  min: 12,
                  max: 30,
                  divisions: 9,
                  label: _fontSize.round().toString(),
                  onChanged: (val) => setState(() => _fontSize = val),
                ),

                const SizedBox(height: 20),
                _buildSectionHeader('Interests'),
                Wrap(
                  spacing: 8,
                  children: _categories.map((category) {
                    final isSelected = _selectedInterests.contains(category);
                    return FilterChip(
                      label: Text(category),
                      selected: isSelected,
                      onSelected: (_) => _toggleInterest(category),
                    );
                  }).toList(),
                ),
                
                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Helper to build Section Titles
  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Text(
        title.toUpperCase(),
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.bold,
          color: Colors.grey,
          letterSpacing: 1.1,
        ),
      ),
    );
  }

  // THE LIVE PREVIEW CARD
  Widget _buildPreviewSection() {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      // Manual color override to show "App Appearance" inside the card
      color: _isDarkMode ? Colors.grey[900] : Colors.white,
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text("Live Preview", style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold)),
                if (_notificationsEnabled)
                  const Icon(Icons.notifications, color: Colors.green, size: 20),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              "Sample Headline",
              style: TextStyle(
                fontSize: _fontSize,
                fontWeight: FontWeight.bold,
                color: _isDarkMode ? Colors.white : Colors.black,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "This is how your text will look. Adjust the slider below to change the reading experience.",
              style: TextStyle(
                fontSize: _fontSize * 0.8,
                color: _isDarkMode ? Colors.white70 : Colors.black87,
              ),
            ),
            const SizedBox(height: 16),
            const Text("Your Interests:", style: TextStyle(fontSize: 12, color: Colors.grey)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 4,
              runSpacing: 4,
              children: _selectedInterests.map((interest) => Chip(
                visualDensity: VisualDensity.compact,
                label: Text(interest, style: const TextStyle(fontSize: 10)),
                backgroundColor: Colors.blue.withOpacity(0.1),
              )).toList(),
            ),
            const SizedBox(height: 16),
            // Volume Indicator
            ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: LinearProgressIndicator(
                value: _volume,
                minHeight: 8,
                backgroundColor: Colors.grey[300],
                valueColor: const AlwaysStoppedAnimation<Color>(Colors.blue),
              ),
            ),
          ],
        ),
      ),
    );
  }
}