import 'package:flutter/material.dart';

void main() {
  runApp(const MultiThemeApp());
}

class MultiThemeApp extends StatefulWidget {
  const MultiThemeApp({super.key});

  @override
  State<MultiThemeApp> createState() => _MultiThemeAppState();
}

class _MultiThemeAppState extends State<MultiThemeApp> {
  // 1. State variable to track the current theme
  ThemeData _currentTheme = AppThemes.lightTheme;
  String _currentThemeName = 'Light';

  // 2. Function to switch themes based on dropdown selection
  void _updateTheme(String? newThemeName) {
    if (newThemeName == null) return;

    setState(() {
      _currentThemeName = newThemeName;
      if (newThemeName == 'Light') {
        _currentTheme = AppThemes.lightTheme;
      } else if (newThemeName == 'Dark') {
        _currentTheme = AppThemes.darkTheme;
      } else {
        _currentTheme = AppThemes.customTheme;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Multi-Theme Switcher',
      debugShowCheckedModeBanner: false,
      // 3. Apply the selected theme here
      theme: _currentTheme,
      home: ThemeSwitcherHome(
        currentThemeName: _currentThemeName,
        onThemeChanged: _updateTheme,
      ),
    );
  }
}

class ThemeSwitcherHome extends StatelessWidget {
  final String currentThemeName;
  final ValueChanged<String?> onThemeChanged;

  const ThemeSwitcherHome({
    super.key,
    required this.currentThemeName,
    required this.onThemeChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Multi-Theme Switcher"),
        actions: [
          // Segmented Control in the AppBar
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: DropdownButton<String>(
              value: currentThemeName,
              underline: const SizedBox(),
              icon: const Icon(Icons.palette, color: Colors.white),
              dropdownColor: Theme.of(context).colorScheme.primary,
              items: ['Light', 'Dark', 'Custom'].map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value, style: const TextStyle(color: Colors.white)),
                );
              }).toList(),
              onChanged: onThemeChanged,
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "Theme Preview",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Text(
              "Current Theme: $currentThemeName",
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            const SizedBox(height: 20),
            
            // Sample Card
            Card(
              elevation: 4,
              child: ListTile(
                leading: const Icon(Icons.info),
                title: const Text("Theme-Aware Card"),
                subtitle: Text("The background and text adjust automatically."),
              ),
            ),
            const SizedBox(height: 20),

            // Sample Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(onPressed: () {}, child: const Text("Elevated")),
                OutlinedButton(onPressed: () {}, child: const Text("Outlined")),
              ],
            ),
            const SizedBox(height: 30),

            // Color Palette Visualizer
            const Text("Theme Color Palette:", style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Row(
              children: [
                _colorBox(Theme.of(context).colorScheme.primary, "Primary"),
                _colorBox(Theme.of(context).colorScheme.secondary, "Secondary"),
                _colorBox(Theme.of(context).colorScheme.surface, "Surface"),
              ],
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _colorBox(Color color, String label) {
    return Expanded(
      child: Column(
        children: [
          Container(height: 50, margin: const EdgeInsets.symmetric(horizontal: 4), color: color),
          Text(label, style: const TextStyle(fontSize: 10)),
        ],
      ),
    );
  }
}

// 4. Define the Theme Data
class AppThemes {
  // LIGHT THEME
  static final lightTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    colorScheme: ColorScheme.fromSeed(
      seedColor: Colors.blue,
      brightness: Brightness.light,
    ),
    appBarTheme: const AppBarTheme(backgroundColor: Colors.blue, foregroundColor: Colors.white),
  );

  // DARK THEME
  static final darkTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: ColorScheme.fromSeed(
      seedColor: Colors.blueGrey,
      brightness: Brightness.dark,
    ),
    appBarTheme: const AppBarTheme(backgroundColor: Colors.black),
  );

  // CUSTOM THEME (Midnight Gold)
  static final customTheme = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    primaryColor: Colors.amber,
    scaffoldBackgroundColor: const Color(0xFF0D1B2A), // Deep Midnight Blue
    colorScheme: const ColorScheme.dark(
      primary: Colors.amber,
      secondary: Colors.orangeAccent,
      surface: Color(0xFF1B263B),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: Color(0xFF1B263B),
      foregroundColor: Colors.amber,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.amber,
        foregroundColor: Colors.black,
      ),
    ),
    cardTheme: const CardThemeData(
  elevation: 4,
  shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.all(Radius.circular(12)),
  ),
),

    textTheme: const TextTheme(
      bodyLarge: TextStyle(color: Colors.amberAccent),
    ),
  );
}