package com.example.multitheme_switcher

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
