import 'package:flutter/material.dart';

void main() {
  runApp(const TodoApp());
}

class TodoApp extends StatelessWidget {
  const TodoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'To-Do List',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const TodoListScreen(),
    );
  }
}

class TodoListScreen extends StatefulWidget {
  const TodoListScreen({super.key});

  @override
  State<TodoListScreen> createState() => _TodoListScreenState();
}

class _TodoListScreenState extends State<TodoListScreen> {
  // State management: Maintaining tasks and their statuses
  final List<String> _tasks = [];
  final List<bool> _taskStatus = [];
  final TextEditingController _taskController = TextEditingController();

  // Function to add a new task
  void _addTask() {
    if (_taskController.text.isNotEmpty) {
      setState(() {
        _tasks.add(_taskController.text);
        _taskStatus.add(false); // New tasks are unchecked by default
      });
      _taskController.clear(); // Clear input field
    }
  }

  // Function to delete a task
  void _deleteTask(int index) {
    setState(() {
      _tasks.removeAt(index);
      _taskStatus.removeAt(index);
    });
  }

  // Function to toggle checkbox
  void _toggleTask(int index) {
    setState(() {
      _taskStatus[index] = !_taskStatus[index];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Basic To-Do List'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          // Input Area
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _taskController,
              decoration: const InputDecoration(
                labelText: 'Enter task name...',
                border: OutlineInputBorder(),
              ),
              onSubmitted: (_) => _addTask(), // Add task on "Enter" key
            ),
          ),
          
          // Scrollable List of Tasks
          Expanded(
            child: _tasks.isEmpty
                ? const Center(child: Text('No tasks yet. Add some!'))
                : ListView.builder(
                    itemCount: _tasks.length,
                    itemBuilder: (context, index) {
                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                        child: ListTile(
                          leading: Checkbox(
                            value: _taskStatus[index],
                            onChanged: (value) => _toggleTask(index),
                          ),
                          title: Text(
                            _tasks[index],
                            style: TextStyle(
                              // Apply strikethrough if task is checked
                              decoration: _taskStatus[index]
                                  ? TextDecoration.lineThrough
                                  : TextDecoration.none,
                              color: _taskStatus[index] ? Colors.grey : Colors.black,
                            ),
                          ),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete, color: Colors.redAccent),
                            onPressed: () => _deleteTask(index),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addTask,
        tooltip: 'Add Task',
        child: const Icon(Icons.add),
      ),
    );
  }
}