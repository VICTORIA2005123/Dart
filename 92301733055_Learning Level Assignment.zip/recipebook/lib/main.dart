import 'package:flutter/material.dart';

void main() {
  runApp(const RecipeApp());
}

class RecipeApp extends StatelessWidget {
  const RecipeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Recipe Book',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.orange,
        useMaterial3: true,
      ),
      home: const RecipeListScreen(),
    );
  }
}

// --- Model ---
class Recipe {
  final String id;
  final String name;
  final String imageUrl;
  final String cookingTime;
  final String difficulty;
  final List<String> ingredients;
  final String instructions;

  Recipe({
    required this.id,
    required this.name,
    required this.imageUrl,
    required this.cookingTime,
    required this.difficulty,
    required this.ingredients,
    required this.instructions,
  });
}

// --- Mock Data ---
final List<Recipe> recipes = [
  Recipe(
    id: '1',
    name: 'Classic Margherita Pizza',
    imageUrl: 'https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?q=80&w=400',
    cookingTime: '30 mins',
    difficulty: 'Medium',
    ingredients: ['Pizza Dough', 'Tomato Sauce', 'Mozzarella', 'Fresh Basil', 'Olive Oil'],
    instructions: '1. Preheat oven to 450°F.\n2. Spread sauce on dough.\n3. Add cheese and bake for 15 mins.\n4. Top with basil.',
  ),
  Recipe(
    id: '2',
    name: 'Creamy Avocado Pasta',
    imageUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=400',
    cookingTime: '15 mins',
    difficulty: 'Easy',
    ingredients: ['Pasta', 'Ripe Avocado', 'Garlic', 'Lemon Juice', 'Parmesan'],
    instructions: '1. Boil pasta.\n2. Blend avocado, garlic, and lemon into a sauce.\n3. Toss pasta with sauce and cheese.',
  ),
  Recipe(
    id: '3',
    name: 'Berry Smoothie Bowl',
    imageUrl: 'https://images.unsplash.com/photo-1590301157890-4810ed352733?q=80&w=400',
    cookingTime: '10 mins',
    difficulty: 'Easy',
    ingredients: ['Frozen Berries', 'Banana', 'Greek Yogurt', 'Granola', 'Honey'],
    instructions: '1. Blend berries, banana, and yogurt until smooth.\n2. Pour into a bowl.\n3. Top with granola and honey.',
  ),
];

// --- Screen 1: Recipe List ---
class RecipeListScreen extends StatelessWidget {
  const RecipeListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My Recipe Book'), centerTitle: true),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: recipes.length,
        itemBuilder: (context, index) {
          final recipe = recipes[index];
          return Card(
            elevation: 4,
            margin: const EdgeInsets.only(bottom: 16),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            child: ListTile(
              contentPadding: const EdgeInsets.all(10),
              leading: Hero(
                tag: recipe.id, // Must be unique for the Hero animation
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.network(
                    recipe.imageUrl,
                    width: 80,
                    height: 80,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              title: Text(
                recipe.name,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              ),
              subtitle: Text('${recipe.cookingTime} • ${recipe.difficulty}'),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => RecipeDetailScreen(recipe: recipe),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

// --- Screen 2: Recipe Detail ---
class RecipeDetailScreen extends StatelessWidget {
  final Recipe recipe;

  const RecipeDetailScreen({super.key, required this.recipe});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // App bar that shrinks and expands
          SliverAppBar(
            expandedHeight: 300,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Hero(
                tag: recipe.id, // Same tag as the list screen
                child: Image.network(
                  recipe.imageUrl,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          SliverList(
            delegate: SliverChildListDelegate([
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Title and Meta Info
                    Text(recipe.name, style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.timer, color: Colors.orange, size: 20),
                        const SizedBox(width: 5),
                        Text(recipe.cookingTime),
                        const SizedBox(width: 20),
                        const Icon(Icons.bar_chart, color: Colors.orange, size: 20),
                        const SizedBox(width: 5),
                        Text(recipe.difficulty),
                      ],
                    ),
                    const Divider(height: 40),

                    // Ingredients Section
                    const Text('Ingredients', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    ...recipe.ingredients.map((item) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(
                            children: [
                              const Icon(Icons.check_circle_outline, size: 18, color: Colors.green),
                              const SizedBox(width: 10),
                              Text(item, style: const TextStyle(fontSize: 16)),
                            ],
                          ),
                        )),

                    const Divider(height: 40),

                    // Instructions Section
                    const Text('Instructions', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    Text(
                      recipe.instructions,
                      style: const TextStyle(fontSize: 16, height: 1.5),
                    ),
                    const SizedBox(height: 50),
                  ],
                ),
              ),
            ]),
          ),
        ],
      ),
    );
  }
}
