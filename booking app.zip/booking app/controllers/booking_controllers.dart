import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

class BookingControllers extends GetxController {
  RxInt capacity = 0.obs;
  RxDouble price = 0.0.obs;
  TextEditingController capacityTxtController = TextEditingController();
  TextEditingController priceTxtController = TextEditingController();
  void setData() {
    try {
      capacity.value = int.parse(capacityTxtController.text);
      price.value = double.parse(priceTxtController.text);
    } catch (e) {
      print(e);
    }
  }
}
