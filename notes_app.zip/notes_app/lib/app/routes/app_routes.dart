// lib/app/routes/app_routes.dart
abstract class AppRoutes {
  static const home = '/home';
  static const initial = '/';
}