package com.example.project_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
