import 'package:flutter/material.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            backgroundColor: Colors.white,
            floating: true,
            toolbarHeight: 90, // Adjust height as needed
            title: Padding(
              padding: const EdgeInsets.only(top: 16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Hi, Syed',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  // Small stars or decorative elements (optional)
                  Row(
                    children: [
                      Icon(Icons.star, size: 16, color: Colors.blue[100]),
                      const SizedBox(width: 4),
                      Icon(Icons.star_border, size: 16, color: Colors.blue[100]),
                    ],
                  ),
                ],
              ),
            ),
            actions: [
              Padding(
                padding: const EdgeInsets.only(top: 16.0, right: 16.0),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.search, color: Colors.black, size: 28),
                      onPressed: () {
                        // Handle search
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.bookmark_border, color: Colors.black, size: 28),
                      onPressed: () {
                        // Handle bookmark
                      },
                    ),
                  ],
                ),
              ),
            ],
            // You can add a flexible space for the wavy background if desired
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  color: Color(0xFFE8F5E9), // Light green for the top part
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(30),
                    bottomRight: Radius.circular(30),
                  ),
                ),
                // Add a slightly wavy effect or just a solid color as in the image
                child: Stack(
                  children: [
                    // This is where you might put an SVG for the wave effect
                    // For simplicity, we'll just have a rounded corner container
                  ],
                ),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Ramadan Offer Section
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        _buildOfferCard(
                          context,
                          'Get Ramadan Offer 2023',
                          '25% on All Islamic Book',
                          Colors.lightBlue.shade50, // Lighter blue for card
                          Colors.lightBlue.shade900, // Darker text for card
                        ),
                        const SizedBox(width: 15),
                        _buildOfferCard(
                          context,
                          'Eid Special Sale',
                          'Flat 30% off on all items',
                          Colors.purple.shade50,
                          Colors.purple.shade900,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 30),

                  // Continue Reading Section
                  _buildSectionHeader('Continue Reading', () {
                    // Handle "See more"
                  }),
                  const SizedBox(height: 15),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        _buildBookItem(
                            'assets/book1.jpg', 'The Wager', 'David Grann'),
                        _buildBookItem('assets/book2.jpg', 'Atomic Habits',
                            'James Clear'),
                        _buildBookItem(
                            'assets/book3.jpg', 'Dog Man', 'Dav Pilkey'),
                        _buildBookItem('assets/book4.jpg', 'Outlive',
                            'Peter Attia'),
                      ],
                    ),
                  ),
                  const SizedBox(height: 30),

                  // Book of the Day Section
                  _buildSectionHeader('Book of the Day', () {
                    // Handle "See more"
                  }),
                  const SizedBox(height: 15),
                  _buildBookOfTheDayCard(
                    'assets/book5.jpg',
                    'It Starts with us',
                    'Colleen Hoover',
                    '\$40',
                    '\$60',
                  ),
                  const SizedBox(height: 30),

                  // This Week Section
                  _buildSectionHeader('This Week', () {
                    // Handle "See more"
                  }),
                  const SizedBox(height: 15),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        _buildMiniBookItem('assets/book6.jpg', 'Hello Beautiful', 'Ann Napolitano'),
                        _buildMiniBookItem('assets/book7.jpg', 'Daisy Jones', 'Taylor Jenkins Reid', isNewArrival: true),
                        _buildMiniBookItem('assets/book8.jpg', 'The Seven Husbands', 'Taylor Jenkins Reid'),
                        _buildMiniBookItem('assets/book9.jpg', 'Lessons in Chemistry', 'Bonnie Garmus', isNewArrival: true),
                      ],
                    ),
                  ),
                  const SizedBox(height: 50), // Extra space at the bottom
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.library_books),
            label: 'Library',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
          ),
        ],
        currentIndex: 0, // Set the initial selected item
        selectedItemColor: Colors.black, // Active icon color
        unselectedItemColor: Colors.grey, // Inactive icon color
        onTap: (index) {
          // Handle navigation
        },
      ),
    );
  }

  Widget _buildOfferCard(
      BuildContext context, String title, String subtitle, Color bgColor, Color textColor) {
    return Container(
      width: MediaQuery.of(context).size.width * 0.8, // Adjust width as needed
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 2,
            blurRadius: 5,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: textColor,
            ),
          ),
          const SizedBox(height: 5),
          Text(
            subtitle,
            style: TextStyle(
              fontSize: 14,
              color: textColor.withOpacity(0.8),
            ),
          ),
          const SizedBox(height: 15),
          ElevatedButton(
            onPressed: () {
              // Handle "Read more"
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.black, // Button background
              foregroundColor: Colors.white, // Button text color
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            child: const Text('Read more'),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title, VoidCallback onSeeMore) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        TextButton(
          onPressed: onSeeMore,
          child: const Text(
            'See more',
            style: TextStyle(
              color: Colors.grey,
              fontSize: 14,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildBookItem(String imagePath, String title, String author) {
    return Container(
      width: 120,
      margin: const EdgeInsets.only(right: 15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.asset(
              imagePath,
              height: 160,
              width: 120,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            title,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 14,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          Text(
            author,
            style: const TextStyle(
              fontSize: 12,
              color: Colors.grey,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  Widget _buildBookOfTheDayCard(
      String imagePath, String title, String author, String currentPrice, String oldPrice) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 2,
            blurRadius: 5,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.asset(
              imagePath,
              height: 120,
              width: 80,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 5),
                Text(
                  author,
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.grey,
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Icon(Icons.star, color: Colors.orange[400], size: 18),
                    Icon(Icons.star, color: Colors.orange[400], size: 18),
                    Icon(Icons.star, color: Colors.orange[400], size: 18),
                    Icon(Icons.star, color: Colors.orange[400], size: 18),
                    Icon(Icons.star_half, color: Colors.orange[400], size: 18),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Text(
                      currentPrice,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      oldPrice,
                      style: const TextStyle(
                        fontSize: 16,
                        color: Colors.grey,
                        decoration: TextDecoration.lineThrough,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMiniBookItem(String imagePath, String title, String author, {bool isNewArrival = false}) {
    return Container(
      width: 100, // Smaller width for mini books
      margin: const EdgeInsets.only(right: 15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.asset(
                  imagePath,
                  height: 130, // Smaller height
                  width: 100,  // Smaller width
                  fit: BoxFit.cover,
                ),
              ),
              if (isNewArrival)
                Positioned(
                  top: 5,
                  left: 5,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                    decoration: BoxDecoration(
                      color: Colors.redAccent,
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: const Text(
                      'New Arrival',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            title,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          Text(
            author,
            style: const TextStyle(
              fontSize: 10,
              color: Colors.grey,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}