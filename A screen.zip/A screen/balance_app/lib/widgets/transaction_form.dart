import 'package:flutter/material.dart';

class TransactionForm extends StatefulWidget {
  final Function(String, String, double) onSubmit;
  const TransactionForm({super.key, required this.onSubmit});

  @override
  State<TransactionForm> createState() => _TransactionFormState();
}

class _TransactionFormState extends State<TransactionForm> {
  final _titleController = TextEditingController();
  final _amountController = TextEditingController();
  String _type = 'expense';

  void _submitData() {
    final enteredTitle = _titleController.text;
    final enteredAmount = double.tryParse(_amountController.text) ?? 0;
    if (enteredTitle.isEmpty || enteredAmount <= 0) return;
    widget.onSubmit(enteredTitle, _type, enteredAmount);
    _titleController.clear();
    _amountController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 5,
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          children: [
            TextField(
              controller: _titleController,
              decoration: const InputDecoration(labelText: 'Title'),
            ),
            TextField(
              controller: _amountController,
              decoration: const InputDecoration(labelText: 'Amount'),
              keyboardType: TextInputType.number,
            ),
            Row(
              children: [
                const Text('Type:'),
                Radio<String>(
                  value: 'expense',
                  groupValue: _type,
                  onChanged: (val) => setState(() => _type = val!),
                ),
                const Text('Expense'),
                Radio<String>(
                  value: 'income',
                  groupValue: _type,
                  onChanged: (val) => setState(() => _type = val!),
                ),
                const Text('Income'),
              ],
            ),
            ElevatedButton(
              onPressed: _submitData,
              child: const Text('Add Transaction'),
            ),
          ],
        ),
      ),
    );
  }
}
