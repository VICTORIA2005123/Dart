import 'package:flutter/material.dart';
import '../models/transaction.dart';

class TransactionList extends StatelessWidget {
  final List<Transaction> transactions;
  const TransactionList({super.key, required this.transactions});

  @override
  Widget build(BuildContext context) {
    return transactions.isEmpty
        ? const Center(child: Text('No transactions added yet!'))
        : ListView.builder(
            itemCount: transactions.length,
            itemBuilder: (ctx, idx) {
              final tx = transactions[idx];
              return Card(
                margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: tx.type == 'income' ? Colors.green : Colors.red,
                    child: Text(tx.type == 'income' ? '+' : '-'),
                  ),
                  title: Text(tx.title),
                  subtitle: Text(
                    '${tx.type.toUpperCase()} | ${tx.amount.toStringAsFixed(2)} | ${tx.date.toLocal().toString().split(' ')[0]}',
                  ),
                ),
              );
            },
          );
  }
}
