import 'package:flutter/material.dart';
import '../models/transaction.dart';
import '../widgets/transaction_list.dart';
import '../widgets/balance_card.dart';
import 'add_transaction_screen.dart';

class ExpenseScreen extends StatefulWidget {
  const ExpenseScreen({super.key});

  @override
  State<ExpenseScreen> createState() => _ExpenseScreenState();
}

class _ExpenseScreenState extends State<ExpenseScreen> {
  final List<Transaction> _transactions = [];
  String _selectedType = 'All';
  final List<String> _typeOptions = ['All', 'Expense', 'Income'];

  void _addTransaction(String title, String type, double amount) {
    setState(() {
      _transactions.insert(
        0,
        Transaction(
          title: title,
          type: type,
          amount: amount,
          date: DateTime.now(),
        ),
      );
    });
  }

  double get _balance {
    double bal = 0;
    for (var tx in _transactions) {
      if (tx.type == 'income') {
        bal += tx.amount;
      } else {
        bal -= tx.amount;
      }
    }
    return bal;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Transactions')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: DropdownButton<String>(
              value: _selectedType,
              items: _typeOptions.map((type) {
                return DropdownMenuItem(
                  value: type,
                  child: Text(type),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _selectedType = value!;
                });
              },
            ),
          ),
          BalanceCard(balance: _balance),
          Expanded(
            child: TransactionList(
              transactions: _selectedType == 'All'
                  ? _transactions
                  : _transactions
                      .where((tx) => tx.type == _selectedType.toLowerCase())
                      .toList(),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (ctx) => AddTransactionScreen(onAdd: _addTransaction),
            ),
          );
        },
        tooltip: 'Add Transaction',
        child: const Icon(Icons.add),
      ),
    );
  }
}
