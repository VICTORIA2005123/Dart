import 'package:flutter/material.dart';
import '../widgets/transaction_form.dart';

class AddTransactionScreen extends StatelessWidget {
  final Function(String, String, double) onAdd;
  const AddTransactionScreen({super.key, required this.onAdd});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Transaction')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: TransactionForm(
          onSubmit: (title, type, amount) {
            onAdd(title, type, amount);
            Navigator.pop(context);
          },
        ),
      ),
    );
  }
}
