class Transaction {
  final String title;
  final String type; // 'expense' or 'income'
  final double amount;
  final DateTime date;

  Transaction({
    required this.title,
    required this.type,
    required this.amount,
    required this.date,
  });
}
