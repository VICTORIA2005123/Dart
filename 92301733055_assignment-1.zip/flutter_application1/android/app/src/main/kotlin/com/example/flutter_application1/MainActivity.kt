package com.example.flutter_application1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
