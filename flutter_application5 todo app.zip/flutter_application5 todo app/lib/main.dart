import 'package:flutter/material.dart';

// The main entry point for the application.
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Todo App',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        // VisualDensity makes the UI more compact and adaptive.
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const TodoScreen(),
    );
  }
}

// Data Model: A simple class to represent a single Todo item.
// This helps in organizing the data for each task.
class Todo {
  String title;
  bool isCompleted;

  Todo({
    required this.title,
    this.isCompleted = false,
  });
}

// The main screen of the app. It's a StatefulWidget because the list of todos
// and the active tab will change.
class TodoScreen extends StatefulWidget {
  const TodoScreen({super.key});

  @override
  State<TodoScreen> createState() => _TodoScreenState();
}

// The State class for TodoScreen. It uses TickerProviderStateMixin to provide
// a Ticker for the TabController's animation.
class _TodoScreenState extends State<TodoScreen> with SingleTickerProviderStateMixin {
  // This is the master list of all todos. The UI will be built based on this list.
  final List<Todo> _todos = [
    Todo(title: 'Buy groceries', isCompleted: false),
    Todo(title: 'Finish Flutter project', isCompleted: true),
    Todo(title: 'Go for a run', isCompleted: false),
  ];

  // The controller for the tabs.
  late TabController _tabController;

  // Controller for the TextField in the "Add Todo" dialog.
  final TextEditingController _addTodoController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Initialize the TabController with 3 tabs.
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    // Dispose controllers to free up resources when the widget is removed.
    _tabController.dispose();
    _addTodoController.dispose();
    super.dispose();
  }

  // --- State Modification Methods ---

  // This method adds a new todo to the master list.
  void _addTodo() {
    // Check if the input is not empty.
    if (_addTodoController.text.trim().isNotEmpty) {
      // Use setState to notify Flutter that the state has changed.
      setState(() {
        _todos.add(Todo(title: _addTodoController.text.trim()));
      });
      // Clear the text field for the next entry.
      _addTodoController.clear();
      // Close the dialog.
      Navigator.of(context).pop();
    }
  }

  // This method toggles the 'isCompleted' status of a todo.
  void _toggleTodoStatus(Todo todo) {
    setState(() {
      todo.isCompleted = !todo.isCompleted;
    });
  }

  // This method removes a todo from the master list.
  void _deleteTodo(Todo todo) {
    setState(() {
      _todos.remove(todo);
    });
  }

  // --- UI Building Methods ---

  // This function shows the dialog for adding a new todo.
  void _showAddTodoDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Add New Todo'),
          content: TextField(
            controller: _addTodoController,
            autofocus: true,
            decoration: const InputDecoration(hintText: 'Enter todo title...'),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                 _addTodoController.clear();
                 Navigator.of(context).pop();
              },
            ),
            ElevatedButton(
              onPressed: _addTodo,
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    // These lists are derived from the master _todos list for each tab.
    final List<Todo> pendingTodos = _todos.where((todo) => !todo.isCompleted).toList();
    final List<Todo> completedTodos = _todos.where((todo) => todo.isCompleted).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Todo Manager'),
        // The 'bottom' property of AppBar is perfect for a TabBar.
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'All'),
            Tab(text: 'Pending'),
            Tab(text: 'Completed'),
          ],
        ),
      ),
      // TabBarView displays the content for the currently selected tab.
      body: TabBarView(
        controller: _tabController,
        children: [
          // Content for the "All" tab.
          TodoList(
            todos: _todos,
            onToggle: _toggleTodoStatus,
            onDelete: _deleteTodo,
          ),
          // Content for the "Pending" tab.
          TodoList(
            todos: pendingTodos,
            onToggle: _toggleTodoStatus,
            onDelete: _deleteTodo,
          ),
          // Content for the "Completed" tab.
          TodoList(
            todos: completedTodos,
            onToggle: _toggleTodoStatus,
            onDelete: _deleteTodo,
          ),
        ],
      ),
      // The FloatingActionButton is used to trigger the "Add Todo" dialog.
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddTodoDialog,
        tooltip: 'Add Todo',
        child: const Icon(Icons.add),
      ),
    );
  }
}

// A reusable widget to display a list of todos.
// This helps keep the main build method clean and promotes code reuse.
class TodoList extends StatelessWidget {
  final List<Todo> todos;
  final Function(Todo) onToggle;
  final Function(Todo) onDelete;

  const TodoList({
    super.key,
    required this.todos,
    required this.onToggle,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    // If the list is empty, display a centered message.
    if (todos.isEmpty) {
      return const Center(
        child: Text(
          'No todos here!',
          style: TextStyle(fontSize: 18, color: Colors.grey),
        ),
      );
    }
    // Otherwise, build a ListView of the todos.
    return ListView.builder(
      itemCount: todos.length,
      itemBuilder: (context, index) {
        final todo = todos[index];
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: ListTile(
            // The leading widget is a Checkbox to toggle completion.
            leading: Checkbox(
              value: todo.isCompleted,
              onChanged: (bool? value) {
                onToggle(todo);
              },
            ),
            // The title's style changes based on the completion status.
            title: Text(
              todo.title,
              style: TextStyle(
                decoration: todo.isCompleted
                    ? TextDecoration.lineThrough
                    : TextDecoration.none,
                color: todo.isCompleted ? Colors.grey : null,
              ),
            ),
            // The trailing widget is a button to delete the todo.
            trailing: IconButton(
              icon: const Icon(Icons.delete_outline, color: Colors.red),
              onPressed: () {
                onDelete(todo);
              },
            ),
          ),
        );
      },
    );
  }
}