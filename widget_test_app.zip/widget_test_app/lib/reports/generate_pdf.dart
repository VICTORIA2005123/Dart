import 'dart:async';

/// Represents a customer with basic information.
class Customer {
  final String name;
  final String mono;

  Customer({required this.name, required this.mono});
}

/// Represents an item in an invoice.
class Item {
  final String prodName;
  final double qty;
  final double rate;
  final double gstPer;

  Item({
    required this.prodName,
    required this.qty,
    required this.rate,
    required this.gstPer,
  });
}

/// A utility class for generating PDF invoices.
/// This version simulates PDF generation and prints a table to the console.
class GeneratePdf {
  /// Simulates the generation of an invoice PDF with a table.
  /// Returns a [Future<String?>] which resolves to a mock file path.
  Future<String?> generateInvoice({
    required Customer customer,
    required List<Item> items,
    required double grandTotal,
    required double cgst,
    required double sgst,
  }) async {
    try {
      await Future.delayed(const Duration(milliseconds: 500));

      print('--- Simulating Invoice Generation ---');
      print('Customer: ${customer.name} (${customer.mono})');
      print('');
      print('Items Table:');
      print(
          '| Product         | Qty   | Rate     | GST%   | Total      |');
      print(
          '|-----------------|-------|----------|--------|------------|');
      for (final item in items) {
        final itemTotal = (item.qty * item.rate) +
            ((item.qty * item.rate) * item.gstPer / 100);
        print(
            '| ${item.prodName.padRight(15)} | ${item.qty.toString().padLeft(5)} | ${item.rate.toStringAsFixed(2).padLeft(8)} | ${item.gstPer.toStringAsFixed(2).padLeft(6)} | ${itemTotal.toStringAsFixed(2).padLeft(10)} |');
      }
      print(
          '|-----------------|-------|----------|--------|------------|');
      print('CGST: \$${cgst.toStringAsFixed(2)}');
      print('SGST: \$${sgst.toStringAsFixed(2)}');
      print('Grand Total: \$${grandTotal.toStringAsFixed(2)}');
      print('--- End Simulation ---');

      final mockFileName =
          'invoice_${customer.name.replaceAll(' ', '_').toLowerCase()}.pdf';
      return '/mock/documents/path/$mockFileName';
    } catch (e) {
      print('Error during simulated invoice generation: $e');
      return null;
    }
  }
}

/// The main entry point of the application.
void main() async {
  // Sample data for demonstration
  final customer = Customer(name: 'Alice Smith', mono: '9876543210');
  final items = [
    Item(prodName: 'Laptop', qty: 1, rate: 1200.0, gstPer: 18.0),
    Item(prodName: 'Mouse', qty: 2, rate: 25.0, gstPer: 5.0),
    Item(prodName: 'Keyboard', qty: 1, rate: 75.0, gstPer: 12.0),
  ];

  double totalBeforeTax = 0;
  for (var item in items) {
    totalBeforeTax += item.qty * item.rate;
  }

  final cgst = totalBeforeTax * 0.09; // Assuming 9% CGST average
  final sgst = totalBeforeTax * 0.09; // Assuming 9% SGST average
  final grandTotal = totalBeforeTax + cgst + sgst;

  final generatePdf = GeneratePdf();

  print('Attempting to generate invoice...\n');
  final filePath = await generatePdf.generateInvoice(
    customer: customer,
    items: items,
    grandTotal: grandTotal,
    cgst: cgst,
    sgst: sgst,
  );

  print('\n--- Application Result ---');
  if (filePath != null) {
    print('Invoice generation simulated successfully. Mock file path: $filePath');
    print('You can imagine a PDF would have been saved or downloaded.');
  } else {
    print('Invoice generation simulated, but no concrete file path was returned.');
    print('An error might have occurred, or the output was handled differently.');
  }
}
/*
    // //Generate PDF grid.
    // final PdfGrid grid = getGrid();
    // //Draw the header section by creating text element
    // final PdfLayoutResult result = drawHeader(page, pageSize, grid);
    // //Draw grid
    // drawGrid(page, grid, result);
    // //Add invoice footer
    // drawFooter(page, pageSize);
    // //Save the PDF document
    // final List<int> bytes = document.saveSync();
    // //Dispose the document.
    // document.dispose();
    // //Save and launch the file.
    // await saveAndLaunchFile(bytes, 'Invoice.pdf');
  

  // //Draws the invoice header
  // static PdfLayoutResult drawHeader(PdfPage page, Size pageSize, PdfGrid grid) {
  //   //Draw rectangle
  //   page.graphics.drawRectangle(
  //     brush: PdfSolidBrush(PdfColor(91, 126, 215)),
  //     bounds: Rect.fromLTWH(0, 0, pageSize.width - 115, 90),
  //   );
  //   //Draw string
  //   page.graphics.drawString(
  //     'INVOICE',
  //     PdfStandardFont(PdfFontFamily.helvetica, 30),
  //     brush: PdfBrushes.white,
  //     bounds: Rect.fromLTWH(25, 0, pageSize.width - 115, 90),
  //     format: PdfStringFormat(lineAlignment: PdfVerticalAlignment.middle),
  //   );

  //   page.graphics.drawRectangle(
  //     bounds: Rect.fromLTWH(400, 0, pageSize.width - 400, 90),
  //     brush: PdfSolidBrush(PdfColor(65, 104, 205)),
  //   );

  //   page.graphics.drawString(
  //     r'$' + getTotalAmount(grid).toString(),
  //     PdfStandardFont(PdfFontFamily.helvetica, 18),
  //     bounds: Rect.fromLTWH(400, 0, pageSize.width - 400, 100),
  //     brush: PdfBrushes.white,
  //     format: PdfStringFormat(
  //       alignment: PdfTextAlignment.center,
  //       lineAlignment: PdfVerticalAlignment.middle,
  //     ),
  //   );

  //   final PdfFont contentFont = PdfStandardFont(PdfFontFamily.helvetica, 9);
  //   //Draw string
  //   page.graphics.drawString(
  //     'Amount',
  //     contentFont,
  //     brush: PdfBrushes.white,
  //     bounds: Rect.fromLTWH(400, 0, pageSize.width - 400, 33),
  //     format: PdfStringFormat(
  //       alignment: PdfTextAlignment.center,
  //       lineAlignment: PdfVerticalAlignment.bottom,
  //     ),
  //   );
  //   //Create data foramt and convert it to text.
  //   final DateFormat format = DateFormat.yMMMMd('en_US');
  //   final String invoiceNumber =
  //       'Invoice Number: 2058557939\r\n\r\nDate: ${format.format(DateTime.now())}';
  //   final Size contentSize = contentFont.measureString(invoiceNumber);
  //   // ignore: leading_newlines_in_multiline_strings
  //   const String address = '''Bill To: \r\n\r\nAbraham Swearegin,
  //       \r\n\r\nUnited States, California, San Mateo,
  //       \r\n\r\n9920 BridgePointe Parkway, \r\n\r\n9365550136''';

  //   PdfTextElement(text: invoiceNumber, font: contentFont).draw(
  //     page: page,
  //     bounds: Rect.fromLTWH(
  //       pageSize.width - (contentSize.width + 30),
  //       120,
  //       contentSize.width + 30,
  //       pageSize.height - 120,
  //     ),
  //   );

  //   return PdfTextElement(text: address, font: contentFont).draw(
  //     page: page,
  //     bounds: Rect.fromLTWH(
  //       30,
  //       120,
  //       pageSize.width - (contentSize.width + 30),
  //       pageSize.height - 120,
  //     ),
  //   )!;
  // }

  // //Draws the grid
  // static void drawGrid(PdfPage page, PdfGrid grid, PdfLayoutResult result) {
  //   Rect? totalPriceCellBounds;
  //   Rect? quantityCellBounds;
  //   //Invoke the beginCellLayout event.
  //   grid.beginCellLayout = (Object sender, PdfGridBeginCellLayoutArgs args) {
  //     final PdfGrid grid = sender as PdfGrid;
  //     if (args.cellIndex == grid.columns.count - 1) {
  //       totalPriceCellBounds = args.bounds;
  //     } else if (args.cellIndex == grid.columns.count - 2) {
  //       quantityCellBounds = args.bounds;
  //     }
  //   };
  //   //Draw the PDF grid and get the result.
  //   result =
  //       grid.draw(
  //         page: page,
  //         bounds: Rect.fromLTWH(0, result.bounds.bottom + 40, 0, 0),
  //       )!;

  //   //Draw grand total.
  //   page.graphics.drawString(
  //     'Grand Total',
  //     PdfStandardFont(PdfFontFamily.helvetica, 9, style: PdfFontStyle.bold),
  //     bounds: Rect.fromLTWH(
  //       quantityCellBounds!.left,
  //       result.bounds.bottom + 10,
  //       quantityCellBounds!.width,
  //       quantityCellBounds!.height,
  //     ),
  //   );
  //   page.graphics.drawString(
  //     getTotalAmount(grid).toString(),
  //     PdfStandardFont(PdfFontFamily.helvetica, 9, style: PdfFontStyle.bold),
  //     bounds: Rect.fromLTWH(
  //       totalPriceCellBounds!.left,
  //       result.bounds.bottom + 10,
  //       totalPriceCellBounds!.width,
  //       totalPriceCellBounds!.height,
  //     ),
  //   );
  // }

  // //Draw the invoice footer data.
  // static void drawFooter(PdfPage page, Size pageSize) {
  //   final PdfPen linePen = PdfPen(
  //     PdfColor(142, 170, 219),
  //     dashStyle: PdfDashStyle.custom,
  //   );
  //   linePen.dashPattern = <double>[3, 3];
  //   //Draw line
  //   page.graphics.drawLine(
  //     linePen,
  //     Offset(0, pageSize.height - 100),
  //     Offset(pageSize.width, pageSize.height - 100),
  //   );

  //   const String footerContent =
  //   // ignore: leading_newlines_in_multiline_strings
  //   '''800 Interchange Blvd.\r\n\r\nSuite 2501, Austin,
  //        TX 78721\r\n\r\nAny Questions? support@adventure-works.com''';

  //   //Added 30 as a margin for the layout
  //   page.graphics.drawString(
  //     footerContent,
  //     PdfStandardFont(PdfFontFamily.helvetica, 9),
  //     format: PdfStringFormat(alignment: PdfTextAlignment.right),
  //     bounds: Rect.fromLTWH(pageSize.width - 30, pageSize.height - 70, 0, 0),
  //   );
  // }

  // //Create PDF grid and return
  // static PdfGrid getGrid() {
  //   //Create a PDF grid
  //   final PdfGrid grid = PdfGrid();
  //   //Secify the columns count to the grid.
  //   grid.columns.add(count: 5);
  //   //Create the header row of the grid.
  //   final PdfGridRow headerRow = grid.headers.add(1)[0];
  //   //Set style
  //   headerRow.style.backgroundBrush = PdfSolidBrush(PdfColor(68, 114, 196));
  //   headerRow.style.textBrush = PdfBrushes.white;
  //   headerRow.cells[0].value = 'Product Id';
  //   headerRow.cells[0].stringFormat.alignment = PdfTextAlignment.center;
  //   headerRow.cells[1].value = 'Product Name';
  //   headerRow.cells[2].value = 'Price';
  //   headerRow.cells[3].value = 'Quantity';
  //   headerRow.cells[4].value = 'Total';
  //   //Add rows
  //   addProducts('CA-1098', 'AWC Logo Cap', 8.99, 2, 17.98, grid);
  //   addProducts('LJ-0192', 'Long-Sleeve Logo Jersey,M', 49.99, 3, 149.97, grid);
  //   addProducts('So-B909-M', 'Mountain Bike Socks,M', 9.5, 2, 19, grid);
  //   addProducts('LJ-0192', 'Long-Sleeve Logo Jersey,M', 49.99, 4, 199.96, grid);
  //   addProducts('FK-5136', 'ML Fork', 175.49, 6, 1052.94, grid);
  //   addProducts('HL-U509', 'Sports-100 Helmet,Black', 34.99, 1, 34.99, grid);
  //   //Apply the table built-in style
  //   grid.applyBuiltInStyle(PdfGridBuiltInStyle.listTable4Accent5);
  //   //Set gird columns width
  //   grid.columns[1].width = 200;
  //   for (int i = 0; i < headerRow.cells.count; i++) {
  //     headerRow.cells[i].style.cellPadding = PdfPaddings(
  //       bottom: 5,
  //       left: 5,
  //       right: 5,
  //       top: 5,
  //     );
  //   }
  //   for (int i = 0; i < grid.rows.count; i++) {
  //     final PdfGridRow row = grid.rows[i];
  //     for (int j = 0; j < row.cells.count; j++) {
  //       final PdfGridCell cell = row.cells[j];
  //       if (j == 0) {
  //         cell.stringFormat.alignment = PdfTextAlignment.center;
  //       }
  //       cell.style.cellPadding = PdfPaddings(
  //         bottom: 5,
  //         left: 5,
  //         right: 5,
  //         top: 5,
  //       );
  //     }
  //   }
  //   return grid;
  // }

  // //Create and row for the grid.
  // static void addProducts(
  //   String productId,
  //   String productName,
  //   double price,
  //   int quantity,
  //   double total,
  //   PdfGrid grid,
  // ) {
  //   final PdfGridRow row = grid.rows.add();
  //   row.cells[0].value = productId;
  //   row.cells[1].value = productName;
  //   row.cells[2].value = price.toString();
  //   row.cells[3].value = quantity.toString();
  //   row.cells[4].value = total.toString();
  // }

  // //Get the total amount.
  // static double getTotalAmount(PdfGrid grid) {
  //   double total = 0;
  //   for (int i = 0; i < grid.rows.count; i++) {
  //     final String value =
  //         grid.rows[i].cells[grid.columns.count - 1].value as String;
  //     total += double.parse(value);
  //   }
  //   return total;
  // }
*/