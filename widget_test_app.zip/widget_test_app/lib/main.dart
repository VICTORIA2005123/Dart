import 'package:flutter/material.dart';
import 'package:widget_test_app/screens/radio_test_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Test App',
      home: RadioTestScreen(),
    );
  }
}