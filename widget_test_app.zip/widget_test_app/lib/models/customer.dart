// lib/models/customer.dart

class Customer {
  String name;
  String mono; // This field was missing or misnamed

  Customer({
    required this.name,
    required this.mono,
  });
}