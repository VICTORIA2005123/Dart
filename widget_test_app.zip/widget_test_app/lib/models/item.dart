class Item {
  final String prodName;
  final double qty;
  final double rate;
  final double gstPer;

  Item({
    required this.prodName,
    required this.qty,
    required this.rate,
    required this.gstPer,
  });
}