import 'package:flutter/material.dart';
import 'package:widget_test_app/models/customer.dart';
import 'package:widget_test_app/models/item.dart';
import 'package:widget_test_app/reports/generate_pdf.dart';

class RadioTestScreen extends StatefulWidget {
  const RadioTestScreen({super.key});

  @override
  State<RadioTestScreen> createState() => _RadioTestScreenState();
}

class _RadioTestScreenState extends State<RadioTestScreen> {
  String selVal = "GST";
  final _formKey = GlobalKey<FormState>();

  late TextEditingController txtCustName;
  late TextEditingController txtCustMono;
  late TextEditingController txtProd;
  late TextEditingController txtQty;
  late TextEditingController txtRate;
  late TextEditingController txtGstPer;

  List<Item> cartItems = [];
  Customer customer = Customer(name: 'Walk-in Customer', mono: 'N/A');
  double cgst = 0;
  double sgst = 0;
  double gtotal = 0;

  bool isCustEdit = false;
  bool isAddFormVisible = false;

  final GeneratePdf pdf = GeneratePdf();

  @override
  void initState() {
    super.initState();
    txtCustName = TextEditingController();
    txtCustMono = TextEditingController();
    txtProd = TextEditingController();
    txtQty = TextEditingController();
    txtRate = TextEditingController();
    txtGstPer = TextEditingController();
  }

  @override
  void dispose() {
    txtCustName.dispose();
    txtCustMono.dispose();
    txtProd.dispose();
    txtQty.dispose();
    txtRate.dispose();
    txtGstPer.dispose();
    super.dispose();
  }

  double _calculateSingleItemTotal(Item item) {
    final itemTotal = item.qty * item.rate;
    final gstAmount = itemTotal * (item.gstPer / 100);
    return itemTotal + gstAmount;
  }

  void _calculateGrandTotals() {
    double tempGTotal = 0;
    double tempTotalGst = 0;
    for (final item in cartItems) {
      tempGTotal += _calculateSingleItemTotal(item);
      tempTotalGst += (item.qty * item.rate) * (item.gstPer / 100);
    }
    setState(() {
      gtotal = tempGTotal;
      cgst = tempTotalGst / 2;
      sgst = tempTotalGst / 2;
    });
  }

  void _clearItemForm() {
    txtProd.clear();
    txtQty.clear();
    txtRate.clear();
    txtGstPer.clear();
    _formKey.currentState?.reset();
  }

  void _addItemToCart() {
    if (!_formKey.currentState!.validate()) {
      return;
    }
    final double qty = double.tryParse(txtQty.text) ?? 0.0;
    final double rate = double.tryParse(txtRate.text) ?? 0.0;
    final double gstPercentage =
        selVal == 'GST' ? (double.tryParse(txtGstPer.text) ?? 0.0) : 0.0;

    cartItems.add(
      Item(
        prodName: txtProd.text,
        qty: qty,
        rate: rate,
        gstPer: gstPercentage,
      ),
    );
    _calculateGrandTotals();
    _clearItemForm();
  }

  void _saveCustomer() {
    if (txtCustName.text.isNotEmpty && txtCustMono.text.isNotEmpty) {
      setState(() {
        customer.name = txtCustName.text;
        customer.mono = txtCustMono.text;
        isCustEdit = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Invoice Creator"),
        actions: [
          IconButton(
            icon: const Icon(Icons.picture_as_pdf),
            tooltip: 'Generate PDF',
            onPressed: () async {
              if (cartItems.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                      content: Text('Please add items to the cart first!')),
                );
                return;
              }
              try {
                await pdf.generateInvoice(
                  customer: customer,
                  items: cartItems,
                  grandTotal: gtotal,
                  cgst: cgst,
                  sgst: sgst,
                );
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('PDF generated successfully!')),
                );
              } catch (e) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Failed to generate PDF: $e')),
                );
              }
            },
          ),
          IconButton(
            onPressed: () => setState(() => isAddFormVisible = !isAddFormVisible),
            icon: Icon(isAddFormVisible ? Icons.close : Icons.add),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            _buildCustomerInfo(),
            if (isAddFormVisible) _buildAddItemForm(),
            const Divider(height: 20, thickness: 1),
            Expanded(
              child: ListView.builder(
                itemCount: cartItems.length,
                itemBuilder: (context, index) {
                  final item = cartItems[index];
                  return ListTile(
                    title: Text(item.prodName),
                    subtitle:
                        Text('${item.rate} * ${item.qty} (@${item.gstPer}%)'),
                    trailing:
                        Text(_calculateSingleItemTotal(item).toStringAsFixed(2)),
                  );
                },
              ),
            ),
            _buildTotalsFooter(),
          ],
        ),
      ),
    );
  }

  Widget _buildCustomerInfo() {
    if (isCustEdit) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              TextFormField(
                controller: txtCustName,
                decoration: const InputDecoration(labelText: "Customer Name"),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: txtCustMono,
                decoration: const InputDecoration(labelText: "Customer Mobile"),
              ),
              const SizedBox(height: 8),
              ElevatedButton(
                onPressed: _saveCustomer,
                child: const Text('Save'),
              ),
            ],
          ),
        ),
      );
    } else {
      return InkWell(
        onTap: () => setState(() {
          txtCustName.text = customer.name;
          txtCustMono.text = customer.mono;
          isCustEdit = true;
        }),
        child: Container(
          width: double.infinity,
          color: Colors.yellow[100],
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(customer.name.isEmpty
                  ? 'Tap to add customer name'
                  : customer.name),
              const SizedBox(height: 8),
              Text(customer.mono.isEmpty
                  ? 'Tap to add mobile no'
                  : customer.mono),
            ],
          ),
        ),
      );
    }
  }

  Widget _buildAddItemForm() {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              Row(children: [
                Flexible(
                  child: RadioListTile<String>(
                    title: const Text("GST"),
                    value: "GST",
                    groupValue: selVal,
                    onChanged: (v) {
                      setState(() {
                        selVal = v!;
                        if (selVal != 'GST') {
                          txtGstPer.clear();
                        }
                      });
                    },
                  ),
                ),
                Flexible(
                  child: RadioListTile<String>(
                    title: const Text("No GST"),
                    value: "WGST",
                    groupValue: selVal,
                    onChanged: (v) {
                      setState(() {
                        selVal = v!;
                        txtGstPer.clear();
                      });
                    },
                  ),
                ),
              ]),
              TextFormField(
                controller: txtProd,
                validator: (v) =>
                    v == null || v.isEmpty ? "Enter product Name" : null,
                decoration: const InputDecoration(labelText: "Product"),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: txtQty,
                keyboardType: TextInputType.number,
                validator: (v) => v == null || v.isEmpty ? "Enter Qty" : null,
                decoration: const InputDecoration(labelText: "Qty"),
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: txtRate,
                keyboardType: TextInputType.number,
                validator: (v) => v == null || v.isEmpty ? "Enter rate" : null,
                decoration: const InputDecoration(labelText: "Rate"),
              ),
              const SizedBox(height: 8),
              if (selVal == 'GST')
                TextFormField(
                  controller: txtGstPer,
                  keyboardType: TextInputType.number,
                  validator: (v) {
                    if (v == null || v.isEmpty) return "Enter GST%";
                    final d = double.tryParse(v);
                    if (d == null || d > 100 || d < 0)
                      return "Enter valid GST% (0-100)";
                    return null;
                  },
                  decoration: const InputDecoration(labelText: "GST %"),
                ),
              const SizedBox(height: 8),
              ElevatedButton(
                onPressed: _addItemToCart,
                child: const Text('Add Item'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTotalsFooter() {
    return Container(
      padding: const EdgeInsets.all(12),
      color: Colors.lightGreenAccent,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Text('CGST: ${cgst.toStringAsFixed(2)}'),
          Text('SGST: ${sgst.toStringAsFixed(2)}'),
          Text(
            'Grand Total: ${gtotal.toStringAsFixed(2)}',
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
        ],
      ),
    );
  }
}

/*import 'package:flutter/material.dart';
import 'package:widget_test_app/models/customer.dart';
import 'package:widget_test_app/models/item.dart';

class RadioTestScreen extends StatefulWidget {
  const RadioTestScreen({super.key});

  @override
  State<RadioTestScreen> createState() => _RadioTestScreenState();
}

class _RadioTestScreenState extends State<RadioTestScreen> {
  String selVal = "GST";
  TextEditingController txtCustName = TextEditingController();
  TextEditingController txtCustMono = TextEditingController();
  TextEditingController txtProd = TextEditingController();
  TextEditingController txtQty = TextEditingController();
  TextEditingController txtRate = TextEditingController();
  TextEditingController txtAmnt = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  TextEditingController txtGstPer = TextEditingController();
  List<Item> cartItems = [];
  Customer customer = Customer(name: '', mono: '');
  double cgst = 0;
  double sgst = 0;
  double gtotal = 0;
  _calculateAmount(v) {
    if (txtQty.text.isNotEmpty && txtRate.text.isNotEmpty) {
      double qty = double.parse(txtQty.text);
      double rate = double.parse(txtRate.text);
      txtAmnt.text = (qty * rate).toStringAsFixed(2);
    }
  }

  _calAmt(double qty, double rate, double gstP) {
    return (qty * rate) + ((qty * rate) * 0.01 * gstP);
  }

  _calTotal() {
    gtotal = 0;
    cgst = 0;
    sgst = 0;
    for (Item i in cartItems) {
      var gstAmnt = i.qty * i.rate * 0.01 * i.gstPer;
      gtotal += (i.qty * i.rate) + gstAmnt;
      cgst += gstAmnt / 2;
      sgst += gstAmnt / 2;
    }
    setState(() {});
  }

  bool isCustEdit = false;
  bool isAdd = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Row(
              children: [
                Radio(
                  value: "GST",
                  groupValue: selVal,
                  onChanged: (v) {
                    selVal = v!;
                    setState(() {});
                  },
                ),
                Text('GST'),
              ],
            ),
            Expanded(
              child: RadioListTile(
                title: Text("Without GST"),
                value: "WGST",
                groupValue: selVal,
                onChanged: (v) {
                  selVal = v!;
                  setState(() {});
                },
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () {
              isAdd = !isAdd;
              setState(() {});
            },
            icon: Icon(isAdd ? Icons.close : Icons.add),
          ),
        ],
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              isCustEdit
                  ? Column(
                    children: [
                      TextFormField(
                        controller: txtCustName,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: "Enter Customer Name",
                          labelText: "Customer Name",
                        ),
                      ),

                      SizedBox(height: 8),
                      TextFormField(
                        controller: txtCustMono,
                        decoration: InputDecoration(
                          border: OutlineInputBorder(),
                          hintText: "Enter Customer Mobile",
                          labelText: "Customer Mobile",
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          if (txtCustName.text.isNotEmpty &&
                              txtCustMono.text.isNotEmpty) {
                            customer.name = txtCustName.text;
                            customer.mono = txtCustMono.text;
                            isCustEdit = false;
                            setState(() {});
                          }
                        },
                        child: Text('Save'),
                      ),
                    ],
                  )
                  : InkWell(
                    onTap: () {
                      isCustEdit = true;
                      setState(() {});
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width * 0.99,
                      color: Colors.yellowAccent,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(customer.name),
                          SizedBox(height: 8),
                          Text(customer.mono),
                        ],
                      ),
                    ),
                  ),
              if (isAdd)
                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      TextFormField(
                        controller: txtProd,
                        validator: (v) {
                          if (v == null || v.isEmpty) {
                            return "Enter product Name";
                          }
                          return null;
                        },
                        decoration: InputDecoration(
                          hintText: "Enter Product",
                          labelText: "Enter Product",
                          border: OutlineInputBorder(),
                        ),
                      ),
                      SizedBox(height: 8),
                      TextFormField(
                        controller: txtQty,
                        validator: (v) {
                          if (v == null || v.isEmpty) {
                            return "Enter Qty";
                          }
                          return null;
                        },
                        onChanged: _calculateAmount,
                        decoration: InputDecoration(
                          hintText: "Enter Qty",
                          labelText: "Enter Qty",
                          border: OutlineInputBorder(),
                        ),
                      ),
                      SizedBox(height: 8),
                      TextFormField(
                        controller: txtRate,
                        validator: (v) {
                          if (v == null || v.isEmpty) {
                            return "Enter rate";
                          }
                          return null;
                        },
                        onChanged: _calculateAmount,
                        decoration: InputDecoration(
                          hintText: "Enter rate",
                          labelText: "Enter rate",
                          border: OutlineInputBorder(),
                        ),
                      ),
                      SizedBox(height: 8),
                      TextFormField(
                        controller: txtAmnt,
                        decoration: InputDecoration(
                          hintText: "Enter amount",
                          labelText: "Enter amount",
                          border: OutlineInputBorder(),
                        ),
                      ),
                      SizedBox(height: 8),
                      if (selVal == 'GST')
                        TextFormField(
                          controller: txtGstPer,
                          validator: (v) {
                            if (v == null || v.isEmpty) {
                              return "Enter GST%";
                            }
                            try {
                              double d = double.parse(v);
                              if (d > 100 || d < 0) {
                                return "Enter GST% between 0-100";
                              }
                            } catch (e) {
                              return "Enter valid number between 0-100";
                            }
                            return null;
                          },
                          decoration: InputDecoration(
                            hintText: "Enter GST%",
                            labelText: "Enter GST%",
                            border: OutlineInputBorder(),
                          ),
                        ),
                      SizedBox(height: 8),
                      ElevatedButton(
                        onPressed: () {
                          if (_formKey.currentState!.validate()) {
                            _formKey.currentState!.save();
                            // calculate logic
                            double amnt = double.parse(txtAmnt.text);
                            if (selVal == "GST") {
                              double gstP = double.parse(txtGstPer.text);
                              cgst = amnt * 0.01 * gstP * 0.5;
                              sgst = amnt * 0.01 * gstP * 0.5;
                              gtotal = amnt + cgst + sgst;
                            } else {
                              gtotal = amnt;
                            }
                            cartItems.add(
                              Item(
                                prodName: txtProd.text,
                                qty: double.parse(txtQty.text),
                                rate: double.parse(txtRate.text),
                                gstPer: double.parse(txtGstPer.text),
                              ),
                            );
                            _calTotal();
                            setState(() {});
                          }
                        },
                        child: Text('Add'),
                      ),
                    ],
                  ),
                ),
              Expanded(
                child: ListView.builder(
                  itemCount: cartItems.length,
                  itemBuilder:
                      (context, index) => ListTile(
                        title: Text('${cartItems[index].prodName}'),
                        subtitle: Text(
                          '${cartItems[index].rate} * ${cartItems[index].qty} (${cartItems[index].gstPer})',
                        ),
                        trailing: Text(
                          _calAmt(
                            cartItems[index].qty,
                            cartItems[index].rate,
                            cartItems[index].gstPer,
                          ).toStringAsFixed(2),
                        ),
                      ),
                ),
              ),
              Container(
                height: 100,
                width: MediaQuery.of(context).size.width,
                color: Colors.lightGreenAccent,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Text('CGST: ${cgst.toStringAsFixed(2)}'),
                    Text('SGST: ${sgst.toStringAsFixed(2)}'),
                    Text('IGST: ${(sgst + cgst).toStringAsFixed(2)}'),
                    Text('Grand Total: ${gtotal.toStringAsFixed(2)}'),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
*/