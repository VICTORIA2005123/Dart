import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'Daily Expense App',
      theme: ThemeData(
        primarySwatch: Colors.green,
        fontFamily: 'Segoe', // Or any other font you prefer
      ),
      home: HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}