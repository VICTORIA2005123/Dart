import 'package:flutter/material.dart';
class AddTransactionScreen extends StatefulWidget {
	const AddTransactionScreen({super.key});

	@override
	State<AddTransactionScreen> createState() => _AddTransactionScreenState();
}

class _AddTransactionScreenState extends State<AddTransactionScreen> {
	final TextEditingController _amountController = TextEditingController();
	String _selectedCategory = 'Food';
	String _selectedPaymentType = 'Cash';

	final List<String> _categories = ['Food', 'Salary', 'Entertainment'];
	final Map<String, IconData> _categoryIcons = {
		'Food': Icons.restaurant,
		'Salary': Icons.attach_money,
		'Entertainment': Icons.movie,
	};

	@override
	Widget build(BuildContext context) {
		return Scaffold(
			backgroundColor: Colors.white,
			appBar: AppBar(
				backgroundColor: Colors.white,
				elevation: 0,
				leading: IconButton(
					icon: Icon(Icons.arrow_back, color: Colors.black),
					onPressed: () => Navigator.of(context).pop(),
				),
				title: Text('Add transaction', style: TextStyle(color: Colors.black)),
				centerTitle: true,
			),
			body: Padding(
				padding: const EdgeInsets.all(20.0),
				child: Column(
					crossAxisAlignment: CrossAxisAlignment.start,
					children: [
						Text('Amount', style: TextStyle(color: Colors.grey)),
						SizedBox(height: 8),
						TextField(
							controller: _amountController,
							keyboardType: TextInputType.number,
							decoration: InputDecoration(
								hintText: '4.00',
								border: OutlineInputBorder(
									borderRadius: BorderRadius.circular(12),
								),
							),
						),
						SizedBox(height: 20),
						Text('Category', style: TextStyle(color: Colors.grey)),
						SizedBox(height: 8),
						Container(
							padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
							decoration: BoxDecoration(
								color: Colors.grey[100],
								borderRadius: BorderRadius.circular(12),
							),
							child: DropdownButtonHideUnderline(
								child: DropdownButton<String>(
									value: _selectedCategory,
									items: _categories.map((cat) {
										return DropdownMenuItem<String>(
											value: cat,
											child: Row(
												children: [
													Icon(_categoryIcons[cat], color: Colors.black),
													SizedBox(width: 8),
													Text(cat),
												],
											),
										);
									}).toList(),
									onChanged: (val) {
										setState(() {
											_selectedCategory = val!;
										});
									},
								),
							),
						),
						SizedBox(height: 20),
						Text('Payment Type', style: TextStyle(color: Colors.grey)),
						SizedBox(height: 8),
						Row(
							children: [
								_buildPaymentTypeRadio('Cash'),
								SizedBox(width: 12),
								_buildPaymentTypeRadio('Credit/Debit Card'),
								SizedBox(width: 12),
								_buildPaymentTypeRadio('Check'),
							],
						),
						Spacer(),
						Row(
							children: [
								Expanded(
									child: OutlinedButton(
										onPressed: () {},
										style: OutlinedButton.styleFrom(
											side: BorderSide(color: Colors.lightGreen),
											shape: RoundedRectangleBorder(
												borderRadius: BorderRadius.circular(30),
											),
										),
										child: Text('Draft', style: TextStyle(color: Colors.lightGreen)),
									),
								),
								SizedBox(width: 16),
								Expanded(
									child: ElevatedButton(
										onPressed: () {},
										style: ElevatedButton.styleFrom(
											backgroundColor: Colors.lightGreen,
											shape: RoundedRectangleBorder(
												borderRadius: BorderRadius.circular(30),
											),
											elevation: 0,
										),
										child: Text('Add', style: TextStyle(color: Colors.white)),
									),
								),
							],
						),
					],
				),
			),
		);
	}

	Widget _buildPaymentTypeRadio(String type) {
		return Expanded(
			child: InkWell(
				onTap: () {
					setState(() {
						_selectedPaymentType = type;
					});
				},
				child: Container(
					padding: EdgeInsets.symmetric(vertical: 12),
					decoration: BoxDecoration(
						color: _selectedPaymentType == type ? Colors.lightGreen.withOpacity(0.2) : Colors.white,
						border: Border.all(
							color: _selectedPaymentType == type ? Colors.lightGreen : Colors.grey[300]!,
						),
						borderRadius: BorderRadius.circular(20),
					),
					child: Row(
						mainAxisAlignment: MainAxisAlignment.center,
						children: [
							Icon(
								_selectedPaymentType == type ? Icons.radio_button_checked : Icons.radio_button_unchecked,
								color: _selectedPaymentType == type ? Colors.lightGreen : Colors.grey,
							),
							SizedBox(width: 8),
							Text(type, style: TextStyle(color: Colors.black)),
						],
					),
				),
			),
		);
	}
}