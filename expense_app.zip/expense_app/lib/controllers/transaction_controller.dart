import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../models/transaction_model.dart';

class TransactionController extends GetxController {
  var transactions = <Transaction>[
    Transaction(
        category: 'Food',
        paymentMethod: 'Card',
        amount: -12.00,
        date: DateTime.now(),
        icon: Icons.fastfood),
    Transaction(
        category: 'Salary',
        paymentMethod: 'Bank Account',
        amount: 6800.00,
        date: DateTime.now(),
        icon: Icons.account_balance),

    Transaction(
        category: 'Entertainment',
        paymentMethod: 'Card',
        amount: -8.00,
        date: DateTime.now(),
        icon: Icons.movie),
    Transaction(
        category: 'Transportation',
        paymentMethod: 'Bank Account',
        amount: -3601.00,
        date: DateTime.now(),
        icon: Icons.account_balance),
    Transaction(
        category: 'Extra Shifts',
        paymentMethod: 'Bank Account',
        amount: 1629.00,
        date: DateTime.now(),
        icon: Icons.account_balance),
  ].obs;

  double get totalIncome =>
      transactions.where((t) => t.amount > 0).fold(0, (sum, t) => sum + t.amount);

  double get totalSpent =>
      transactions.where((t) => t.amount < 0).fold(0, (sum, t) => sum + t.amount);

  void addTransaction(Transaction transaction) {
    transactions.insert(0, transaction);
  }
}