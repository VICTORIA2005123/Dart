import 'package:flutter/material.dart';

class Transaction {
  final String category;
  final String paymentMethod;
  final double amount;
  final DateTime date;
  final IconData icon;

  Transaction({
    required this.category,
    required this.paymentMethod,
    required this.amount,
    required this.date,
    required this.icon,
  });
}