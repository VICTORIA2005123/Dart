import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

// The main entry point for the application.
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Unit Converter',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
        // Using CardTheme for a consistent card appearance.
        cardTheme: CardThemeData(
          elevation: 4,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          margin: const EdgeInsets.symmetric(vertical: 8.0),
        ),
      ),
      home: const UnitConverterScreen(),
    );
  }
}

// Data structure to hold all conversion information.
// Using a Map makes it easy to manage and extend categories and units.
final Map<String, List<String>> categories = {
  'Length': ['Meter', 'Kilometer', 'Centimeter', 'Mile', 'Foot', 'Inch'],
  'Weight': ['Gram', 'Kilogram', 'Pound', 'Ounce'],
  'Temperature': ['Celsius', 'Fahrenheit', 'Kelvin'],
  'Area': ['Square Meter', 'Square Kilometer', 'Square Mile', 'Acre'],
};

// Map to store conversion factors relative to a base unit for each category.
// The base unit for each category has a factor of 1.0.
final Map<String, Map<String, double>> conversionFactors = {
  'Length': {
    'Meter': 1.0, 'Kilometer': 1000.0, 'Centimeter': 0.01,
    'Mile': 1609.34, 'Foot': 0.3048, 'Inch': 0.0254,
  },
  'Weight': {
    'Gram': 1.0, 'Kilogram': 1000.0, 'Pound': 453.592, 'Ounce': 28.3495,
  },
  'Area': {
    'Square Meter': 1.0, 'Square Kilometer': 1000000.0,
    'Square Mile': 2590000.0, 'Acre': 4046.86,
  },
};


// The main screen of the app. It's a StatefulWidget because the UI
// changes based on user input and selections.
class UnitConverterScreen extends StatefulWidget {
  const UnitConverterScreen({super.key});

  @override
  State<UnitConverterScreen> createState() => _UnitConverterScreenState();
}

class _UnitConverterScreenState extends State<UnitConverterScreen> {
  // State variables to hold the current state of the converter.
  String _selectedCategory = 'Length';
  String _fromUnit = 'Meter';
  String _toUnit = 'Kilometer';
  final String _inputValue = '';
  String _result = '0';

  // Controller for the input TextField.
  final TextEditingController _inputController = TextEditingController();

  @override
  void initState() {
    super.initState();
    // Add a listener to the controller to perform conversion in real-time.
    _inputController.addListener(_performConversion);
  }

  @override
  void dispose() {
    _inputController.dispose();
    super.dispose();
  }

  // The core conversion logic function.
  void _performConversion() {
    final double? inputValue = double.tryParse(_inputController.text);
    if (inputValue == null) {
      setState(() => _result = '0');
      return;
    }

    double outputValue = 0;

    // Temperature is a special case with non-linear formulas.
    if (_selectedCategory == 'Temperature') {
      outputValue = _convertTemperature(inputValue);
    } else {
      // For other categories, use the conversion factor method.
      final double? fromFactor = conversionFactors[_selectedCategory]![_fromUnit];
      final double? toFactor = conversionFactors[_selectedCategory]![_toUnit];
      
      // Convert the input value to the base unit, then to the target unit.
      final double valueInBaseUnit = inputValue * fromFactor!;
      outputValue = valueInBaseUnit / toFactor!;
    }
    
    // Update the state to display the result, formatted to a reasonable precision.
    setState(() {
      _result = outputValue.toStringAsFixed(4);
    });
  }

  // Specific function to handle temperature conversions.
  double _convertTemperature(double value) {
    if (_fromUnit == _toUnit) return value;
    
    // Convert from the source unit to Celsius first (as a base).
    double valueInCelsius;
    if (_fromUnit == 'Fahrenheit') {
      valueInCelsius = (value - 32) * 5 / 9;
    } else if (_fromUnit == 'Kelvin') {
      valueInCelsius = value - 273.15;
    } else { // It's already Celsius
      valueInCelsius = value;
    }

    // Now convert from Celsius to the target unit.
    if (_toUnit == 'Fahrenheit') {
      return (valueInCelsius * 9 / 5) + 32;
    } else if (_toUnit == 'Kelvin') {
      return valueInCelsius + 273.15;
    } else { // Target is Celsius
      return valueInCelsius;
    }
  }


  @override
  Widget build(BuildContext context) {
    // Get the list of units for the currently selected category.
    final List<String> currentUnits = categories[_selectedCategory]!;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Unit Converter'),
      ),
      // Use SingleChildScrollView to prevent overflow on smaller screens.
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // --- Category Selection ---
            _buildDropdown(
              label: 'Category',
              value: _selectedCategory,
              items: categories.keys.toList(),
              onChanged: (newValue) {
                setState(() {
                  _selectedCategory = newValue!;
                  // Reset units to the first in the new category's list.
                  _fromUnit = categories[_selectedCategory]![0];
                  _toUnit = categories[_selectedCategory]![1];
                   _performConversion();
                });
              },
            ),
            const SizedBox(height: 20),

            // --- Input Value Field ---
            TextField(
              controller: _inputController,
              decoration: const InputDecoration(
                labelText: 'Enter Value',
                border: OutlineInputBorder(),
              ),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
            ),
            const SizedBox(height: 20),

            // --- Unit Selection Dropdowns ---
            Row(
              children: [
                Expanded(
                  child: _buildDropdown(
                    label: 'From',
                    value: _fromUnit,
                    items: currentUnits,
                    onChanged: (newValue) {
                       setState(() {
                         _fromUnit = newValue!;
                         _performConversion();
                       });
                    },
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: _buildDropdown(
                    label: 'To',
                    value: _toUnit,
                    items: currentUnits,
                    onChanged: (newValue) {
                       setState(() {
                         _toUnit = newValue!;
                         _performConversion();
                       });
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 30),

            // --- Result Display ---
            Card(
              color: Theme.of(context).primaryColor,
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    Text(
                      'Result',
                      style: TextStyle(fontSize: 20, color: Colors.white.withOpacity(0.8)),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      _result,
                      style: const TextStyle(
                        fontSize: 36,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // A helper method to create styled DropdownButton widgets to reduce code repetition.
  Widget _buildDropdown({
    required String label,
    required String value,
    required List<String> items,
    required ValueChanged<String?> onChanged,
  }) {
    return InputDecorator(
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(5.0)),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          isExpanded: true,
          items: items.map((String val) {
            return DropdownMenuItem<String>(
              value: val,
              child: Text(val),
            );
          }).toList(),
          onChanged: onChanged,
        ),
      ),
    );
  }
}