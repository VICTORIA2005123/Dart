package com.example.a_screen

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
