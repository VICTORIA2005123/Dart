import 'dart:async';

void main() {
  // 1. Create a StreamController to manage the stream.
  //    Use .broadcast() if multiple listeners are expected.
  StreamController<String> controller = StreamController<String>.broadcast();

  // 2. Obtain the Stream from the StreamController.
  Stream<String> myStream = controller.stream;

  // 3. Subscribe to the stream using the listen() method.
  //    The provided callback function will be executed for each data event.
  StreamSubscription<String> subscription1 = myStream.listen(
    (data) {
      print('Listener 1 received: $data');
    },
    onError: (error) {
      print('Listener 1 encountered error: $error');
    },
    onDone: () {
      print('Listener 1: Stream is closed!');
    },
  );

  // You can have multiple listeners on a broadcast stream.
  StreamSubscription<String> subscription2 = myStream.listen(
    (data) {
      print('Listener 2 received: $data');
    },
    onError: (error) {
      print('Listener 2 encountered error: $error');
    },
    onDone: () {
      print('Listener 2: Stream is closed!');
    },
  );

  // 4. Add data events to the stream using the controller's sink.
  controller.sink.add('Hello');
  controller.sink.add('World');

  // 5. Add an error event.
  controller.addError('Something went wrong!');

  // 6. Close the stream when no more events are expected.
  controller.close();

  // 7. You can also cancel subscriptions if needed.
  // subscription1.cancel();
}