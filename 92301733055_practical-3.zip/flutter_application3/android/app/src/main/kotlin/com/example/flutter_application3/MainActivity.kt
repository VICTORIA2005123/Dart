package com.example.flutter_application3

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
