import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'dart:math';

// Main entry point for the Flutter application.
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Loan Calculator',
      theme: ThemeData(
        // Setting a clean, white primary swatch for the app theme.
        primarySwatch: Colors.blue,
        // Using a white background color for the scaffold to match the design.
        scaffoldBackgroundColor: Colors.white,
        // Customizing the app bar theme for a consistent look.
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          elevation: 0,
          iconTheme: IconThemeData(color: Colors.black),
          titleTextStyle: TextStyle(color: Colors.black, fontSize: 20, fontWeight: FontWeight.bold),
        ),
      ),
      home: const LoanCalculatorScreen(),
    );
  }
}

// This is the main screen of the application. It's a StatefulWidget
// because the input values and calculated results will change.
class LoanCalculatorScreen extends StatefulWidget {
  const LoanCalculatorScreen({super.key});

  @override
  State<LoanCalculatorScreen> createState() => _LoanCalculatorScreenState();
}

class _LoanCalculatorScreenState extends State<LoanCalculatorScreen> {
  // Controllers to manage the text input from TextFormFields.
  final TextEditingController _principalController = TextEditingController(text: '1000');
  final TextEditingController _interestController = TextEditingController(text: '10');

  // State variables for loan tenure.
  int _tenureYears = 10;
  int _tenureMonths = 0;

  // State variables to hold the calculated results.
  double _emi = 0.0;
  double _totalInterest = 0.0;
  double _totalPayment = 0.0;

  // A GlobalKey for the Form widget to manage form state and validation.
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    // Add listeners to the controllers to calculate EMI in real-time.
    _principalController.addListener(_calculateEmi);
    _interestController.addListener(_calculateEmi);
    // Perform an initial calculation when the screen loads.
    _calculateEmi();
  }

  @override
  void dispose() {
    // Clean up the controllers when the widget is disposed.
    _principalController.dispose();
    _interestController.dispose();
    super.dispose();
  }

  // The core function to calculate the EMI and other results.
  void _calculateEmi() {
    // Get the numerical values from the controllers.
    final double principal = double.tryParse(_principalController.text) ?? 0;
    final double annualRate = double.tryParse(_interestController.text) ?? 0;

    // Check if the inputs are valid for calculation.
    if (principal > 0 && annualRate > 0) {
      // Convert annual interest rate to monthly and tenure to total months.
      final double monthlyRate = annualRate / 12 / 100;
      final int totalMonths = _tenureYears * 12 + _tenureMonths;

      if (totalMonths > 0) {
        // EMI formula: P * r * (1+r)^n / ((1+r)^n - 1)
        _emi = (principal * monthlyRate * pow(1 + monthlyRate, totalMonths)) / (pow(1 + monthlyRate, totalMonths) - 1);
        _totalPayment = _emi * totalMonths;
        _totalInterest = _totalPayment - principal;
      } else {
        // If tenure is zero, results are reset.
        _emi = 0;
        _totalPayment = principal;
        _totalInterest = 0;
      }
    } else {
       _emi = 0;
       _totalPayment = principal;
       _totalInterest = 0;
    }

    // Call setState to update the UI with the new results.
    setState(() {});
  }

  // A helper function to format numbers into Indian Rupee currency format.
  String _formatCurrency(double amount) {
    // Using the intl package for locale-aware currency formatting.
    final formatter = NumberFormat.currency(locale: 'en_IN', symbol: '₹', decimalDigits: 2);
    return formatter.format(amount);
  }

  // This function displays a dialog to pick the loan tenure.
  Future<void> _showTenurePicker() async {
    // Show a dialog that returns the selected tenure.
    final result = await showDialog<Map<String, int>>(
      context: context,
      builder: (BuildContext context) {
        // Using StatefulBuilder to manage the state within the dialog.
        return TenurePickerDialog(initialYears: _tenureYears, initialMonths: _tenureMonths);
      },
    );

    // If the user selected a tenure, update the state and recalculate.
    if (result != null) {
      setState(() {
        _tenureYears = result['years']!;
        _tenureMonths = result['months']!;
      });
      _calculateEmi();
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: const Icon(Icons.arrow_back),
        title: const Text('Loan calculator'),
        centerTitle: true,
      ),
      // SingleChildScrollView prevents content from overflowing on smaller screens.
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // --- Input Section ---
              _buildInputField(
                controller: _principalController,
                label: 'Principal',
              ),
              const SizedBox(height: 24),
              _buildInputField(
                controller: _interestController,
                label: 'Interest (percentage)',
              ),
              const SizedBox(height: 24),

              // --- Tenure Selection Row ---
              const Text('Loan tenure', style: TextStyle(fontSize: 16, color: Colors.grey)),
              const SizedBox(height: 8),
              InkWell(
                onTap: _showTenurePicker,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '$_tenureYears years $_tenureMonths month',
                        style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                      ),
                      const Icon(Icons.arrow_forward_ios, color: Colors.grey),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Center(
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      textStyle: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    onPressed: _calculateEmi,
                    child: const Text('Calculate'),
                  ),
                ),
              ),
              const SizedBox(height: 30),
              const Divider(),
              const SizedBox(height: 20),

              // --- Results Section ---
              Center(child: Text('EMI', style: TextStyle(fontSize: 16, color: Colors.grey[600]))),
              Center(child: Text('$_tenureYears years $_tenureMonths month', style: TextStyle(fontSize: 16, color: Colors.grey[600]))),
              const SizedBox(height: 8),
              Center(
                child: Text(
                  _formatCurrency(_emi),
                  style: const TextStyle(fontSize: 48, fontWeight: FontWeight.bold, color: Colors.orange),
                ),
              ),
              const SizedBox(height: 30),
              const Divider(),
              const SizedBox(height: 20),

              // --- Payment Breakdown Section ---
              Text('Total payment', style: TextStyle(fontSize: 16, color: Colors.grey[600])),
              Text(_formatCurrency(_totalPayment), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              
              // Visual breakdown bar
              _buildBreakdownBar(),
              const SizedBox(height: 20),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                   _buildBreakdownInfo('Total principal', _formatCurrency(double.tryParse(_principalController.text) ?? 0), Colors.teal),
                   _buildBreakdownInfo('Total interest', _formatCurrency(_totalInterest), Colors.orange),
                ],
              ),
               const SizedBox(height: 40),
               const Center(child: Text('Powered by Mi Calculator', style: TextStyle(color: Colors.grey)))
            ],
          ),
        ),
      ),
    );
  }

  // A helper method to create styled TextFormFields to reduce code repetition.
  Widget _buildInputField({required TextEditingController controller, required String label}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 16, color: Colors.grey)),
        TextFormField(
          controller: controller,
          keyboardType: TextInputType.number,
          style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
          decoration: const InputDecoration(
            border: InputBorder.none, // Creates a clean, borderless input field.
          ),
        ),
      ],
    );
  }
  
  // A helper widget for the breakdown info section.
  Widget _buildBreakdownInfo(String label, String value, Color dotColor) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
               Icon(Icons.circle, color: dotColor, size: 12),
               const SizedBox(width: 4),
               Text(label, style: const TextStyle(color: Colors.grey)),
            ],
          ),
          Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        ],
      );
  }

  // A helper widget to build the visual principal/interest bar.
  Widget _buildBreakdownBar() {
     // Calculate the proportion of principal and interest.
     final double principalAmount = double.tryParse(_principalController.text) ?? 0;
     final double total = _totalPayment > 0 ? _totalPayment : 1; // Avoid division by zero.
     final double principalFlex = (principalAmount / total) * 100;
     final double interestFlex = (_totalInterest / total) * 100;

     return ClipRRect(
       borderRadius: BorderRadius.circular(10),
       child: Row(
         children: [
           Expanded(
             flex: principalFlex.toInt(),
             child: Container(
               height: 10,
               color: Colors.teal,
             ),
           ),
           Expanded(
             flex: interestFlex.toInt(),
             child: Container(
               height: 10,
               color: Colors.orange,
             ),
           ),
         ],
       ),
     );
  }
}

// A custom StatefulWidget for the tenure selection dialog.
class TenurePickerDialog extends StatefulWidget {
  final int initialYears;
  final int initialMonths;

  const TenurePickerDialog({
    super.key,
    required this.initialYears,
    required this.initialMonths,
  });

  @override
  _TenurePickerDialogState createState() => _TenurePickerDialogState();
}

class _TenurePickerDialogState extends State<TenurePickerDialog> {
  late int _selectedYears;
  late int _selectedMonths;

  @override
  void initState() {
    super.initState();
    _selectedYears = widget.initialYears;
    _selectedMonths = widget.initialMonths;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Select Loan Tenure'),
      content: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          // Dropdown for selecting years.
          DropdownButton<int>(
            value: _selectedYears,
            items: List.generate(31, (index) => DropdownMenuItem(value: index, child: Text('$index Years'))),
            onChanged: (value) {
              if (value != null) {
                setState(() {
                  _selectedYears = value;
                });
              }
            },
          ),
          // Dropdown for selecting months.
          DropdownButton<int>(
            value: _selectedMonths,
            items: List.generate(12, (index) => DropdownMenuItem(value: index, child: Text('$index Months'))),
            onChanged: (value) {
              if (value != null) {
                setState(() {
                  _selectedMonths = value;
                });
              }
            },
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(), // Cancel button
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            // Confirm button returns the selected values.
            Navigator.of(context).pop({'years': _selectedYears, 'months': _selectedMonths});
          },
          child: const Text('OK'),
        ),
      ],
    );
  }
}